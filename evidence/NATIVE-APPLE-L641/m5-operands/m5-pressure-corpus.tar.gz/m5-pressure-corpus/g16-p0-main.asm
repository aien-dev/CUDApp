   0: 7C A0 10 06                                get_sr           0, r7, sr32 (thread_position_in_grid.x)
   4: 67 10 54 08 00 07 20 00 51 01 00 40 46 00  device_load      5, i32, x, r4, u0_u1, r7, lsl 2, 0, wait 0, 1, 1, 0
  12: 67 00 54 04 01 07 20 00 51 01 00 40 46 00  device_load      5, i32, x, r2, u2_u3, r7, lsl 2, 0, 1, 1, 0
  20: 67 00 44 00 02 07 20 00 51 01 00 40 46 00  device_load      5, i32, x, r0, u4_u5, r7, lsl 2, 0, 1, 0, 0
  2e: 9F 00 56 0C 02 08 20 00 D0 21 2A 00        imadd            r6, r2, r4, r0, wait 5
  3a: 9F 01 54 0A 02 02 38 8C 11 04              iadd             r5, 1, r7.cache
  44: 9F 01 54 06 02 04 38 8C 11 04              iadd             r3, 2, r7.cache
  4e: 9F 01 54 02 02 06 38 88 11 04              iadd             r1, 3, r7
  58: E7 00 54 0C 03 07 21 00 11 00 00 90 11 00  device_store     0, i32, x, r6, u6_u7, r7.discard, lsl 2, 0, 1, 1
  66: E7 00 54 08 03 05 21 00 11 00 00 90 11 00  device_store     0, i32, x, r4, u6_u7, r5.discard, lsl 2, 0, 1, 1
  74: E7 00 54 04 03 03 21 00 11 00 00 90 11 00  device_store     0, i32, x, r2, u6_u7, r3.discard, lsl 2, 0, 1, 1
  82: E7 00 54 00 03 01 21 00 11 00 00 90 11 00  device_store     0, i32, x, r0, u6_u7, r1.discard, lsl 2, 0, 1, 1
  90: 0E 00 00 00                                stop             
