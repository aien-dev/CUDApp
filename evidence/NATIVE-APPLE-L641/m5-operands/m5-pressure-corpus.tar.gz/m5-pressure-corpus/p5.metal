#include <metal_stdlib>
using namespace metal;
kernel void k(volatile device const uint *a [[buffer(0)]], volatile device const uint *b [[buffer(1)]], volatile device const uint *c [[buffer(2)]], device uint *out [[buffer(3)]], uint gid [[thread_position_in_grid]]) {
uint va=a[gid]; uint vb=b[gid]; uint vc=c[gid];
uint v0=a[gid+1];
uint v1=a[gid+2];
uint v2=a[gid+3];
uint v3=a[gid+4];
uint v4=a[gid+5];
out[gid] = va * vb + vc;
out[gid+1] = va; out[gid+2] = vb; out[gid+3] = vc;
out[gid+4] = v0;
out[gid+5] = v1;
out[gid+6] = v2;
out[gid+7] = v3;
out[gid+8] = v4;
}
