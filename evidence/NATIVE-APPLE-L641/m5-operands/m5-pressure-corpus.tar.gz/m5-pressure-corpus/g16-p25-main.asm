   0: 1C A0 10 06                                get_sr           0, r1, sr32 (thread_position_in_grid.x)
   4: 9F 11 54 6A 02 02 08 8C 11 04              iadd             r53, 1, r1.cache, wait 0
   e: 9F 01 54 66 02 04 08 8C 11 04              iadd             r51, 2, r1.cache
  18: 9F 01 54 62 02 06 08 88 11 04              iadd             r49, 3, r1
  22: 67 00 54 68 00 01 20 00 11 00 00 40 46 00  device_load      0, i32, x, r52, u0_u1, r1, lsl 2, 0, 1, 1, 0
  30: 67 00 54 64 01 01 20 00 11 00 00 40 46 00  device_load      0, i32, x, r50, u2_u3, r1, lsl 2, 0, 1, 1, 0
  3e: 67 00 54 60 02 01 20 00 11 00 00 40 46 00  device_load      0, i32, x, r48, u4_u5, r1, lsl 2, 0, 1, 1, 0
  4c: 67 00 54 5C 00 35 20 00 51 00 00 40 46 00  device_load      1, i32, x, r46, u0_u1, r53, lsl 2, 0, 1, 1, 0
  5a: 67 00 54 58 00 33 20 00 51 00 00 40 46 00  device_load      1, i32, x, r44, u0_u1, r51, lsl 2, 0, 1, 1, 0
  68: 67 00 44 54 00 31 20 00 51 00 00 40 46 00  device_load      1, i32, x, r42, u0_u1, r49, lsl 2, 0, 1, 0, 0
  76: 9F 01 54 5E 02 08 08 8C 11 04              iadd             r47, 4, r1.cache
  80: 9F 01 54 5A 02 0A 08 8C 11 04              iadd             r45, 5, r1.cache
  8a: 9F 01 54 56 02 0C 08 8C 11 04              iadd             r43, 6, r1.cache
  94: 9F 01 54 52 02 0E 08 8C 11 04              iadd             r41, 7, r1.cache
  9e: 9F 01 54 4E 02 10 08 8C 11 04              iadd             r39, 8, r1.cache
  a8: 9F 01 54 4A 02 12 08 8C 11 04              iadd             r37, 9, r1.cache
  b2: 9F 01 64 46 02 14 08 8C 11 04              iadd.q2.todo     r35, 10, r1.cache
  bc: 9F 01 54 42 02 16 08 8C 11 04              iadd             r33, 11, r1.cache
  c6: 9F 01 54 3E 02 18 08 8C 11 04              iadd             r31, 12, r1.cache
  d0: 9F 01 54 3A 02 1A 08 8C 11 04              iadd             r29, 13, r1.cache
  da: 9F 01 54 36 02 1C 08 8C 11 04              iadd             r27, 14, r1.cache
  e4: 67 00 54 50 00 2F 20 00 51 00 00 40 46 00  device_load      1, i32, x, r40, u0_u1, r47, lsl 2, 0, 1, 1, 0
  f2: 67 00 54 4C 00 2D 20 00 51 00 00 40 46 00  device_load      1, i32, x, r38, u0_u1, r45, lsl 2, 0, 1, 1, 0
 100: 67 00 54 48 00 2B 20 00 51 01 00 40 46 00  device_load      5, i32, x, r36, u0_u1, r43, lsl 2, 0, 1, 1, 0
 10e: 67 00 54 44 00 29 20 00 51 01 00 40 46 00  device_load      5, i32, x, r34, u0_u1, r41, lsl 2, 0, 1, 1, 0
 11c: 67 00 54 40 00 27 20 00 51 01 00 40 46 00  device_load      5, i32, x, r32, u0_u1, r39, lsl 2, 0, 1, 1, 0
 12a: 67 00 54 3C 00 25 20 00 51 01 00 40 46 00  device_load      5, i32, x, r30, u0_u1, r37, lsl 2, 0, 1, 1, 0
 138: 67 00 54 38 00 23 20 00 51 01 00 40 46 00  device_load      5, i32, x, r28, u0_u1, r35, lsl 2, 0, 1, 1, 0
 146: 67 00 54 34 00 21 20 00 51 01 00 40 46 00  device_load      5, i32, x, r26, u0_u1, r33, lsl 2, 0, 1, 1, 0
 154: 67 00 54 30 00 1F 20 00 51 01 00 40 46 00  device_load      5, i32, x, r24, u0_u1, r31, lsl 2, 0, 1, 1, 0
 162: 67 00 54 2C 00 1D 20 00 91 00 00 40 46 00  device_load      2, i32, x, r22, u0_u1, r29, lsl 2, 0, 1, 1, 0
 170: 67 00 44 06 00 1B 20 00 91 00 00 40 46 00  device_load      2, i32, x, r3, u0_u1, r27, lsl 2, 0, 1, 0, 0
 17e: 9F 01 54 32 02 1E 08 8C 11 04              iadd             r25, 15, r1.cache
 188: 9F 01 54 2E 02 20 08 8C 11 04              iadd             r23, 16, r1.cache
 192: 9F 01 54 0A 02 22 08 8C 11 04              iadd             r5, 17, r1.cache
 19c: 9F 01 54 2A 02 24 08 8C 11 04              iadd             r21, 18, r1.cache
 1a6: 9F 01 54 26 02 26 08 8C 11 04              iadd             r19, 19, r1.cache
 1b0: 9F 01 54 22 02 28 08 8C 11 04              iadd             r17, 20, r1.cache
 1ba: 9F 01 64 1E 02 2A 08 8C 11 04              iadd.q2.todo     r15, 21, r1.cache
 1c4: 9F 01 54 1A 02 2C 08 8C 11 04              iadd             r13, 22, r1.cache
 1ce: 9F 01 54 16 02 2E 08 8C 11 04              iadd             r11, 23, r1.cache
 1d8: 9F 01 54 12 02 30 08 8C 11 04              iadd             r9, 24, r1.cache
 1e2: 9F 01 54 0E 02 32 08 88 11 04              iadd             r7, 25, r1
 1ec: 67 00 54 28 00 19 20 00 91 00 00 40 46 00  device_load      2, i32, x, r20, u0_u1, r25, lsl 2, 0, 1, 1, 0
 1fa: 67 00 54 24 00 17 20 00 91 00 00 40 46 00  device_load      2, i32, x, r18, u0_u1, r23, lsl 2, 0, 1, 1, 0
 208: 67 00 54 20 00 05 20 00 91 00 00 40 46 00  device_load      2, i32, x, r16, u0_u1, r5, lsl 2, 0, 1, 1, 0
 216: 67 00 54 1C 00 15 20 00 91 00 00 40 46 00  device_load      2, i32, x, r14, u0_u1, r21, lsl 2, 0, 1, 1, 0
 224: 67 00 54 18 00 13 20 00 91 00 00 40 46 00  device_load      2, i32, x, r12, u0_u1, r19, lsl 2, 0, 1, 1, 0
 232: 67 00 54 14 00 11 20 00 91 00 00 40 46 00  device_load      2, i32, x, r10, u0_u1, r17, lsl 2, 0, 1, 1, 0
 240: 67 00 54 10 00 0F 20 00 11 01 00 40 46 00  device_load      4, i32, x, r8, u0_u1, r15, lsl 2, 0, 1, 1, 0
 24e: 67 00 54 0C 00 0D 20 00 11 01 00 40 46 00  device_load      4, i32, x, r6, u0_u1, r13, lsl 2, 0, 1, 1, 0
 25c: 67 00 54 08 00 0B 20 00 11 01 00 40 46 00  device_load      4, i32, x, r4, u0_u1, r11, lsl 2, 0, 1, 1, 0
 26a: 67 00 54 04 00 09 20 00 11 01 00 40 46 00  device_load      4, i32, x, r2, u0_u1, r9, lsl 2, 0, 1, 1, 0
 278: 67 00 44 00 00 07 20 00 D1 00 00 40 46 00  device_load      3, i32, x, r0, u0_u1, r7, lsl 2, 0, 1, 0, 0
 286: 9F 10 54 6C 02 C8 A0 01 D3 21 2A 00        imadd            r54, r50, r52, r48, wait 0
 292: E7 00 54 6C 03 01 20 00 51 00 00 90 11 00  device_store     1, i32, x, r54, u6_u7, r1, lsl 2, 0, 1, 1
 2a0: E7 00 54 68 03 35 21 00 51 00 00 90 11 00  device_store     1, i32, x, r52, u6_u7, r53.discard, lsl 2, 0, 1, 1
 2ae: E7 00 54 64 03 33 21 00 51 00 00 90 11 00  device_store     1, i32, x, r50, u6_u7, r51.discard, lsl 2, 0, 1, 1
 2bc: E7 00 54 60 03 31 21 00 51 00 00 90 11 00  device_store     1, i32, x, r48, u6_u7, r49.discard, lsl 2, 0, 1, 1
 2ca: E7 20 54 5C 03 2F 21 00 51 00 00 90 11 00  device_store     1, i32, x, r46, u6_u7, r47.discard, lsl 2, 0, wait 1, 1, 1
 2d8: E7 00 54 58 03 2D 21 00 51 00 00 90 11 00  device_store     1, i32, x, r44, u6_u7, r45.discard, lsl 2, 0, 1, 1
 2e6: E7 00 54 54 03 2B 21 00 51 00 00 90 11 00  device_store     1, i32, x, r42, u6_u7, r43.discard, lsl 2, 0, 1, 1
 2f4: E7 00 54 50 03 29 21 00 51 00 00 90 11 00  device_store     1, i32, x, r40, u6_u7, r41.discard, lsl 2, 0, 1, 1
 302: E7 00 54 4C 03 27 21 00 51 00 00 90 11 00  device_store     1, i32, x, r38, u6_u7, r39.discard, lsl 2, 0, 1, 1
 310: E7 00 56 48 03 25 21 00 51 00 00 90 11 00  device_store     1, i32, x, r36, u6_u7, r37.discard, lsl 2, 0, wait 5, 1, 1
 31e: E7 00 54 44 03 23 21 00 51 00 00 90 11 00  device_store     1, i32, x, r34, u6_u7, r35.discard, lsl 2, 0, 1, 1
 32c: E7 00 54 40 03 21 21 00 51 00 00 90 11 00  device_store     1, i32, x, r32, u6_u7, r33.discard, lsl 2, 0, 1, 1
 33a: E7 00 54 3C 03 1F 21 00 51 00 00 90 11 00  device_store     1, i32, x, r30, u6_u7, r31.discard, lsl 2, 0, 1, 1
 348: E7 00 54 38 03 1D 21 00 51 00 00 90 11 00  device_store     1, i32, x, r28, u6_u7, r29.discard, lsl 2, 0, 1, 1
 356: E7 00 54 34 03 1B 21 00 51 00 00 90 11 00  device_store     1, i32, x, r26, u6_u7, r27.discard, lsl 2, 0, 1, 1
 364: E7 00 54 30 03 19 21 00 51 00 00 90 11 00  device_store     1, i32, x, r24, u6_u7, r25.discard, lsl 2, 0, 1, 1
 372: E7 40 54 2C 03 17 21 00 51 00 00 90 11 00  device_store     1, i32, x, r22, u6_u7, r23.discard, lsl 2, 0, wait 2, 1, 1
 380: E7 00 54 06 03 05 21 00 51 00 00 90 11 00  device_store     1, i32, x, r3, u6_u7, r5.discard, lsl 2, 0, 1, 1
 38e: 9F 01 54 0A 02 34 08 8C 11 04              iadd             r5, 26, r1.cache
 398: 9F 01 54 06 02 36 08 8C 11 04              iadd             r3, 27, r1.cache
 3a2: 9F 01 54 02 02 38 08 88 15 04              iadd             r1, 28, r1.discard
 3ac: E7 00 54 28 03 15 21 00 51 00 00 90 11 00  device_store     1, i32, x, r20, u6_u7, r21.discard, lsl 2, 0, 1, 1
 3ba: E7 00 54 24 03 13 21 00 11 00 00 90 11 00  device_store     0, i32, x, r18, u6_u7, r19.discard, lsl 2, 0, 1, 1
 3c8: E7 00 54 20 03 11 21 00 11 00 00 90 11 00  device_store     0, i32, x, r16, u6_u7, r17.discard, lsl 2, 0, 1, 1
 3d6: E7 00 54 1C 03 0F 21 00 11 00 00 90 11 00  device_store     0, i32, x, r14, u6_u7, r15.discard, lsl 2, 0, 1, 1
 3e4: E7 00 54 18 03 0D 21 00 11 00 00 90 11 00  device_store     0, i32, x, r12, u6_u7, r13.discard, lsl 2, 0, 1, 1
 3f2: E7 00 54 14 03 0B 21 00 11 00 00 90 11 00  device_store     0, i32, x, r10, u6_u7, r11.discard, lsl 2, 0, 1, 1
 400: E7 00 55 10 03 09 21 00 11 00 00 90 11 00  device_store     0, i32, x, r8, u6_u7, r9.discard, lsl 2, 0, wait 4, 1, 1
 40e: E7 00 54 0C 03 07 21 00 11 00 00 90 11 00  device_store     0, i32, x, r6, u6_u7, r7.discard, lsl 2, 0, 1, 1
 41c: E7 00 54 08 03 05 21 00 11 00 00 90 11 00  device_store     0, i32, x, r4, u6_u7, r5.discard, lsl 2, 0, 1, 1
 42a: E7 00 54 04 03 03 21 00 11 00 00 90 11 00  device_store     0, i32, x, r2, u6_u7, r3.discard, lsl 2, 0, 1, 1
 438: E7 80 54 00 03 01 21 00 11 00 00 90 11 00  device_store     0, i32, x, r0, u6_u7, r1.discard, lsl 2, 0, wait 3, 1, 1
 446: 0E 00 00 00                                stop             
