   0: 1C A0 10 06                                get_sr           0, r1, sr32 (thread_position_in_grid.x)
   4: 67 10 54 5C 00 01 20 00 11 00 00 40 46 00  device_load      0, i32, x, r46, u0_u1, r1, lsl 2, 0, wait 0, 1, 1, 0
  12: 67 00 54 58 01 01 20 00 11 00 00 40 46 00  device_load      0, i32, x, r44, u2_u3, r1, lsl 2, 0, 1, 1, 0
  20: 67 00 44 54 02 01 20 00 11 00 00 40 46 00  device_load      0, i32, x, r42, u4_u5, r1, lsl 2, 0, 1, 0, 0
  2e: 9F 01 54 5E 02 02 08 8C 11 04              iadd             r47, 1, r1.cache
  38: 9F 01 54 5A 02 04 08 8C 11 04              iadd             r45, 2, r1.cache
  42: 9F 01 54 56 02 06 08 8C 11 04              iadd             r43, 3, r1.cache
  4c: 9F 01 54 52 02 08 08 8C 11 04              iadd             r41, 4, r1.cache
  56: 9F 01 54 4E 02 0A 08 8C 11 04              iadd             r39, 5, r1.cache
  60: 9F 01 54 4A 02 0C 08 8C 11 04              iadd             r37, 6, r1.cache
  6a: 9F 01 64 46 02 0E 08 8C 11 04              iadd.q2.todo     r35, 7, r1.cache
  74: 9F 01 54 42 02 10 08 8C 11 04              iadd             r33, 8, r1.cache
  7e: 9F 01 54 3E 02 12 08 8C 11 04              iadd             r31, 9, r1.cache
  88: 9F 01 54 3A 02 14 08 8C 11 04              iadd             r29, 10, r1.cache
  92: 9F 01 54 36 02 16 08 8C 11 04              iadd             r27, 11, r1.cache
  9c: 67 00 54 50 00 2F 20 00 51 00 00 40 46 00  device_load      1, i32, x, r40, u0_u1, r47, lsl 2, 0, 1, 1, 0
  aa: 67 00 54 4C 00 2D 20 00 51 00 00 40 46 00  device_load      1, i32, x, r38, u0_u1, r45, lsl 2, 0, 1, 1, 0
  b8: 67 00 54 48 00 2B 20 00 51 00 00 40 46 00  device_load      1, i32, x, r36, u0_u1, r43, lsl 2, 0, 1, 1, 0
  c6: 67 00 54 44 00 29 20 00 51 00 00 40 46 00  device_load      1, i32, x, r34, u0_u1, r41, lsl 2, 0, 1, 1, 0
  d4: 67 00 54 40 00 27 20 00 51 00 00 40 46 00  device_load      1, i32, x, r32, u0_u1, r39, lsl 2, 0, 1, 1, 0
  e2: 67 00 54 3C 00 25 20 00 51 01 00 40 46 00  device_load      5, i32, x, r30, u0_u1, r37, lsl 2, 0, 1, 1, 0
  f0: 67 00 54 38 00 23 20 00 51 01 00 40 46 00  device_load      5, i32, x, r28, u0_u1, r35, lsl 2, 0, 1, 1, 0
  fe: 67 00 54 34 00 21 20 00 51 01 00 40 46 00  device_load      5, i32, x, r26, u0_u1, r33, lsl 2, 0, 1, 1, 0
 10c: 67 00 54 30 00 1F 20 00 51 01 00 40 46 00  device_load      5, i32, x, r24, u0_u1, r31, lsl 2, 0, 1, 1, 0
 11a: 67 00 54 2C 00 1D 20 00 51 01 00 40 46 00  device_load      5, i32, x, r22, u0_u1, r29, lsl 2, 0, 1, 1, 0
 128: 67 00 44 06 00 1B 20 00 51 01 00 40 46 00  device_load      5, i32, x, r3, u0_u1, r27, lsl 2, 0, 1, 0, 0
 136: 9F 01 54 32 02 18 08 8C 11 04              iadd             r25, 12, r1.cache
 140: 9F 01 54 2E 02 1A 08 8C 11 04              iadd             r23, 13, r1.cache
 14a: 9F 01 54 0A 02 1C 08 8C 11 04              iadd             r5, 14, r1.cache
 154: 9F 01 54 2A 02 1E 08 8C 11 04              iadd             r21, 15, r1.cache
 15e: 9F 01 54 26 02 20 08 8C 11 04              iadd             r19, 16, r1.cache
 168: 9F 01 54 22 02 22 08 8C 11 04              iadd             r17, 17, r1.cache
 172: 9F 01 64 1E 02 24 08 8C 11 04              iadd.q2.todo     r15, 18, r1.cache
 17c: 9F 01 54 1A 02 26 08 8C 11 04              iadd             r13, 19, r1.cache
 186: 9F 01 54 16 02 28 08 8C 11 04              iadd             r11, 20, r1.cache
 190: 9F 01 54 12 02 2A 08 8C 11 04              iadd             r9, 21, r1.cache
 19a: 9F 01 54 0E 02 2C 08 88 11 04              iadd             r7, 22, r1
 1a4: 67 00 54 28 00 19 20 00 91 00 00 40 46 00  device_load      2, i32, x, r20, u0_u1, r25, lsl 2, 0, 1, 1, 0
 1b2: 67 00 54 24 00 17 20 00 91 00 00 40 46 00  device_load      2, i32, x, r18, u0_u1, r23, lsl 2, 0, 1, 1, 0
 1c0: 67 00 54 20 00 05 20 00 91 00 00 40 46 00  device_load      2, i32, x, r16, u0_u1, r5, lsl 2, 0, 1, 1, 0
 1ce: 67 00 54 1C 00 15 20 00 91 00 00 40 46 00  device_load      2, i32, x, r14, u0_u1, r21, lsl 2, 0, 1, 1, 0
 1dc: 67 00 54 18 00 13 20 00 91 00 00 40 46 00  device_load      2, i32, x, r12, u0_u1, r19, lsl 2, 0, 1, 1, 0
 1ea: 67 00 54 14 00 11 20 00 91 00 00 40 46 00  device_load      2, i32, x, r10, u0_u1, r17, lsl 2, 0, 1, 1, 0
 1f8: 67 00 54 10 00 0F 20 00 91 00 00 40 46 00  device_load      2, i32, x, r8, u0_u1, r15, lsl 2, 0, 1, 1, 0
 206: 67 00 54 0C 00 0D 20 00 11 01 00 40 46 00  device_load      4, i32, x, r6, u0_u1, r13, lsl 2, 0, 1, 1, 0
 214: 67 00 54 08 00 0B 20 00 11 01 00 40 46 00  device_load      4, i32, x, r4, u0_u1, r11, lsl 2, 0, 1, 1, 0
 222: 67 00 54 04 00 09 20 00 11 01 00 40 46 00  device_load      4, i32, x, r2, u0_u1, r9, lsl 2, 0, 1, 1, 0
 230: 67 00 44 00 00 07 20 00 D1 00 00 40 46 00  device_load      3, i32, x, r0, u0_u1, r7, lsl 2, 0, 1, 0, 0
 23e: 9F 10 54 60 02 B0 70 A1 D2 21 2A 00        imadd            r48, r44, r46, r42, wait 0
 24a: E7 00 54 60 03 01 20 00 51 00 00 90 11 00  device_store     1, i32, x, r48, u6_u7, r1, lsl 2, 0, 1, 1
 258: E7 00 54 5C 03 2F 21 00 51 00 00 90 11 00  device_store     1, i32, x, r46, u6_u7, r47.discard, lsl 2, 0, 1, 1
 266: E7 00 54 58 03 2D 21 00 51 00 00 90 11 00  device_store     1, i32, x, r44, u6_u7, r45.discard, lsl 2, 0, 1, 1
 274: E7 00 54 54 03 2B 21 00 51 00 00 90 11 00  device_store     1, i32, x, r42, u6_u7, r43.discard, lsl 2, 0, 1, 1
 282: E7 20 54 50 03 29 21 00 51 00 00 90 11 00  device_store     1, i32, x, r40, u6_u7, r41.discard, lsl 2, 0, wait 1, 1, 1
 290: E7 00 54 4C 03 27 21 00 51 00 00 90 11 00  device_store     1, i32, x, r38, u6_u7, r39.discard, lsl 2, 0, 1, 1
 29e: E7 00 54 48 03 25 21 00 51 00 00 90 11 00  device_store     1, i32, x, r36, u6_u7, r37.discard, lsl 2, 0, 1, 1
 2ac: E7 00 54 44 03 23 21 00 51 00 00 90 11 00  device_store     1, i32, x, r34, u6_u7, r35.discard, lsl 2, 0, 1, 1
 2ba: E7 00 54 40 03 21 21 00 51 00 00 90 11 00  device_store     1, i32, x, r32, u6_u7, r33.discard, lsl 2, 0, 1, 1
 2c8: E7 00 56 3C 03 1F 21 00 51 00 00 90 11 00  device_store     1, i32, x, r30, u6_u7, r31.discard, lsl 2, 0, wait 5, 1, 1
 2d6: E7 00 54 38 03 1D 21 00 51 00 00 90 11 00  device_store     1, i32, x, r28, u6_u7, r29.discard, lsl 2, 0, 1, 1
 2e4: E7 00 54 34 03 1B 21 00 51 00 00 90 11 00  device_store     1, i32, x, r26, u6_u7, r27.discard, lsl 2, 0, 1, 1
 2f2: E7 00 54 30 03 19 21 00 51 00 00 90 11 00  device_store     1, i32, x, r24, u6_u7, r25.discard, lsl 2, 0, 1, 1
 300: E7 00 54 2C 03 17 21 00 51 00 00 90 11 00  device_store     1, i32, x, r22, u6_u7, r23.discard, lsl 2, 0, 1, 1
 30e: E7 00 54 06 03 05 21 00 51 00 00 90 11 00  device_store     1, i32, x, r3, u6_u7, r5.discard, lsl 2, 0, 1, 1
 31c: 9F 01 54 0A 02 2E 08 8C 11 04              iadd             r5, 23, r1.cache
 326: 9F 01 54 06 02 30 08 8C 11 04              iadd             r3, 24, r1.cache
 330: 9F 01 54 02 02 32 08 88 15 04              iadd             r1, 25, r1.discard
 33a: E7 40 54 28 03 15 21 00 51 00 00 90 11 00  device_store     1, i32, x, r20, u6_u7, r21.discard, lsl 2, 0, wait 2, 1, 1
 348: E7 00 54 24 03 13 21 00 11 00 00 90 11 00  device_store     0, i32, x, r18, u6_u7, r19.discard, lsl 2, 0, 1, 1
 356: E7 00 54 20 03 11 21 00 11 00 00 90 11 00  device_store     0, i32, x, r16, u6_u7, r17.discard, lsl 2, 0, 1, 1
 364: E7 00 54 1C 03 0F 21 00 11 00 00 90 11 00  device_store     0, i32, x, r14, u6_u7, r15.discard, lsl 2, 0, 1, 1
 372: E7 00 54 18 03 0D 21 00 11 00 00 90 11 00  device_store     0, i32, x, r12, u6_u7, r13.discard, lsl 2, 0, 1, 1
 380: E7 00 54 14 03 0B 21 00 11 00 00 90 11 00  device_store     0, i32, x, r10, u6_u7, r11.discard, lsl 2, 0, 1, 1
 38e: E7 00 54 10 03 09 21 00 11 00 00 90 11 00  device_store     0, i32, x, r8, u6_u7, r9.discard, lsl 2, 0, 1, 1
 39c: E7 00 55 0C 03 07 21 00 11 00 00 90 11 00  device_store     0, i32, x, r6, u6_u7, r7.discard, lsl 2, 0, wait 4, 1, 1
 3aa: E7 00 54 08 03 05 21 00 11 00 00 90 11 00  device_store     0, i32, x, r4, u6_u7, r5.discard, lsl 2, 0, 1, 1
 3b8: E7 00 54 04 03 03 21 00 11 00 00 90 11 00  device_store     0, i32, x, r2, u6_u7, r3.discard, lsl 2, 0, 1, 1
 3c6: E7 80 54 00 03 01 21 00 11 00 00 90 11 00  device_store     0, i32, x, r0, u6_u7, r1.discard, lsl 2, 0, wait 3, 1, 1
 3d4: 0E 00 00 00                                stop             
