   0: 1C A0 10 06                                get_sr           0, r1, sr32 (thread_position_in_grid.x)
   4: 9F 11 54 4A 02 02 08 8C 11 04              iadd             r37, 1, r1.cache, wait 0
   e: 9F 01 64 46 02 04 08 8C 11 04              iadd.q2.todo     r35, 2, r1.cache
  18: 9F 01 54 42 02 06 08 8C 11 04              iadd             r33, 3, r1.cache
  22: 9F 01 54 3E 02 08 08 8C 11 04              iadd             r31, 4, r1.cache
  2c: 9F 01 54 3A 02 0A 08 8C 11 04              iadd             r29, 5, r1.cache
  36: 9F 01 54 36 02 0C 08 88 11 04              iadd             r27, 6, r1
  40: 67 00 54 48 00 01 20 00 51 01 00 40 46 00  device_load      5, i32, x, r36, u0_u1, r1, lsl 2, 0, 1, 1, 0
  4e: 67 00 54 44 01 01 20 00 51 01 00 40 46 00  device_load      5, i32, x, r34, u2_u3, r1, lsl 2, 0, 1, 1, 0
  5c: 67 00 54 40 02 01 20 00 51 01 00 40 46 00  device_load      5, i32, x, r32, u4_u5, r1, lsl 2, 0, 1, 1, 0
  6a: 67 00 54 3C 00 25 20 00 11 00 00 40 46 00  device_load      0, i32, x, r30, u0_u1, r37, lsl 2, 0, 1, 1, 0
  78: 67 00 54 38 00 23 20 00 11 00 00 40 46 00  device_load      0, i32, x, r28, u0_u1, r35, lsl 2, 0, 1, 1, 0
  86: 67 00 54 34 00 21 20 00 11 00 00 40 46 00  device_load      0, i32, x, r26, u0_u1, r33, lsl 2, 0, 1, 1, 0
  94: 67 00 54 30 00 1F 20 00 11 00 00 40 46 00  device_load      0, i32, x, r24, u0_u1, r31, lsl 2, 0, 1, 1, 0
  a2: 67 00 54 2C 00 1D 20 00 11 00 00 40 46 00  device_load      0, i32, x, r22, u0_u1, r29, lsl 2, 0, 1, 1, 0
  b0: 67 00 44 06 00 1B 20 00 11 01 00 40 46 00  device_load      4, i32, x, r3, u0_u1, r27, lsl 2, 0, 1, 0, 0
  be: 9F 01 54 32 02 0E 08 8C 11 04              iadd             r25, 7, r1.cache
  c8: 9F 01 54 2E 02 10 08 8C 11 04              iadd             r23, 8, r1.cache
  d2: 9F 01 54 0A 02 12 08 8C 11 04              iadd             r5, 9, r1.cache
  dc: 9F 01 54 2A 02 14 08 8C 11 04              iadd             r21, 10, r1.cache
  e6: 9F 01 54 26 02 16 08 8C 11 04              iadd             r19, 11, r1.cache
  f0: 9F 01 54 22 02 18 08 8C 11 04              iadd             r17, 12, r1.cache
  fa: 9F 01 64 1E 02 1A 08 8C 11 04              iadd.q2.todo     r15, 13, r1.cache
 104: 9F 01 54 1A 02 1C 08 8C 11 04              iadd             r13, 14, r1.cache
 10e: 9F 01 54 16 02 1E 08 8C 11 04              iadd             r11, 15, r1.cache
 118: 9F 01 54 12 02 20 08 8C 11 04              iadd             r9, 16, r1.cache
 122: 9F 01 54 0E 02 22 08 88 11 04              iadd             r7, 17, r1
 12c: 67 00 54 28 00 19 20 00 D1 00 00 40 46 00  device_load      3, i32, x, r20, u0_u1, r25, lsl 2, 0, 1, 1, 0
 13a: 67 00 54 24 00 17 20 00 D1 00 00 40 46 00  device_load      3, i32, x, r18, u0_u1, r23, lsl 2, 0, 1, 1, 0
 148: 67 00 54 20 00 05 20 00 D1 00 00 40 46 00  device_load      3, i32, x, r16, u0_u1, r5, lsl 2, 0, 1, 1, 0
 156: 67 00 54 1C 00 15 20 00 D1 00 00 40 46 00  device_load      3, i32, x, r14, u0_u1, r21, lsl 2, 0, 1, 1, 0
 164: 67 00 54 18 00 13 20 00 D1 00 00 40 46 00  device_load      3, i32, x, r12, u0_u1, r19, lsl 2, 0, 1, 1, 0
 172: 67 00 54 14 00 11 20 00 51 00 00 40 46 00  device_load      1, i32, x, r10, u0_u1, r17, lsl 2, 0, 1, 1, 0
 180: 67 00 54 10 00 0F 20 00 51 00 00 40 46 00  device_load      1, i32, x, r8, u0_u1, r15, lsl 2, 0, 1, 1, 0
 18e: 67 00 54 0C 00 0D 20 00 51 00 00 40 46 00  device_load      1, i32, x, r6, u0_u1, r13, lsl 2, 0, 1, 1, 0
 19c: 67 00 54 08 00 0B 20 00 51 00 00 40 46 00  device_load      1, i32, x, r4, u0_u1, r11, lsl 2, 0, 1, 1, 0
 1aa: 67 00 54 04 00 09 20 00 51 00 00 40 46 00  device_load      1, i32, x, r2, u0_u1, r9, lsl 2, 0, 1, 1, 0
 1b8: 67 00 44 00 00 07 20 00 91 00 00 40 46 00  device_load      2, i32, x, r0, u0_u1, r7, lsl 2, 0, 1, 0, 0
 1c6: 9F 00 56 4C 02 88 20 01 D2 21 2A 00        imadd            r38, r34, r36, r32, wait 5
 1d2: E7 00 54 4C 03 01 20 00 51 00 00 90 11 00  device_store     1, i32, x, r38, u6_u7, r1, lsl 2, 0, 1, 1
 1e0: E7 00 54 48 03 25 21 00 51 00 00 90 11 00  device_store     1, i32, x, r36, u6_u7, r37.discard, lsl 2, 0, 1, 1
 1ee: E7 00 54 44 03 23 21 00 51 00 00 90 11 00  device_store     1, i32, x, r34, u6_u7, r35.discard, lsl 2, 0, 1, 1
 1fc: E7 00 54 40 03 21 21 00 51 00 00 90 11 00  device_store     1, i32, x, r32, u6_u7, r33.discard, lsl 2, 0, 1, 1
 20a: E7 10 54 3C 03 1F 21 00 51 00 00 90 11 00  device_store     1, i32, x, r30, u6_u7, r31.discard, lsl 2, 0, wait 0, 1, 1
 218: E7 00 54 38 03 1D 21 00 51 00 00 90 11 00  device_store     1, i32, x, r28, u6_u7, r29.discard, lsl 2, 0, 1, 1
 226: E7 00 54 34 03 1B 21 00 51 00 00 90 11 00  device_store     1, i32, x, r26, u6_u7, r27.discard, lsl 2, 0, 1, 1
 234: E7 00 54 30 03 19 21 00 51 00 00 90 11 00  device_store     1, i32, x, r24, u6_u7, r25.discard, lsl 2, 0, 1, 1
 242: E7 00 54 2C 03 17 21 00 51 00 00 90 11 00  device_store     1, i32, x, r22, u6_u7, r23.discard, lsl 2, 0, 1, 1
 250: E7 00 55 06 03 05 21 00 51 00 00 90 11 00  device_store     1, i32, x, r3, u6_u7, r5.discard, lsl 2, 0, wait 4, 1, 1
 25e: 9F 01 54 0A 02 24 08 8C 11 04              iadd             r5, 18, r1.cache
 268: 9F 01 54 06 02 26 08 8C 11 04              iadd             r3, 19, r1.cache
 272: 9F 01 54 02 02 28 08 88 15 04              iadd             r1, 20, r1.discard
 27c: E7 80 54 28 03 15 21 00 51 00 00 90 11 00  device_store     1, i32, x, r20, u6_u7, r21.discard, lsl 2, 0, wait 3, 1, 1
 28a: E7 00 54 24 03 13 21 00 11 00 00 90 11 00  device_store     0, i32, x, r18, u6_u7, r19.discard, lsl 2, 0, 1, 1
 298: E7 00 54 20 03 11 21 00 11 00 00 90 11 00  device_store     0, i32, x, r16, u6_u7, r17.discard, lsl 2, 0, 1, 1
 2a6: E7 00 54 1C 03 0F 21 00 11 00 00 90 11 00  device_store     0, i32, x, r14, u6_u7, r15.discard, lsl 2, 0, 1, 1
 2b4: E7 00 54 18 03 0D 21 00 11 00 00 90 11 00  device_store     0, i32, x, r12, u6_u7, r13.discard, lsl 2, 0, 1, 1
 2c2: E7 20 54 14 03 0B 21 00 11 00 00 90 11 00  device_store     0, i32, x, r10, u6_u7, r11.discard, lsl 2, 0, wait 1, 1, 1
 2d0: E7 00 54 10 03 09 21 00 11 00 00 90 11 00  device_store     0, i32, x, r8, u6_u7, r9.discard, lsl 2, 0, 1, 1
 2de: E7 00 54 0C 03 07 21 00 11 00 00 90 11 00  device_store     0, i32, x, r6, u6_u7, r7.discard, lsl 2, 0, 1, 1
 2ec: E7 00 54 08 03 05 21 00 11 00 00 90 11 00  device_store     0, i32, x, r4, u6_u7, r5.discard, lsl 2, 0, 1, 1
 2fa: E7 00 54 04 03 03 21 00 11 00 00 90 11 00  device_store     0, i32, x, r2, u6_u7, r3.discard, lsl 2, 0, 1, 1
 308: E7 40 54 00 03 01 21 00 11 00 00 90 11 00  device_store     0, i32, x, r0, u6_u7, r1.discard, lsl 2, 0, wait 2, 1, 1
 316: 0E 00 00 00                                stop             
