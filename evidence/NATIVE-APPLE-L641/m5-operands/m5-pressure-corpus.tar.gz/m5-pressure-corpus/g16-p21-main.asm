   0: 1C A0 10 06                                get_sr           0, r1, sr32 (thread_position_in_grid.x)
   4: 67 10 54 58 00 01 20 00 11 00 00 40 46 00  device_load      0, i32, x, r44, u0_u1, r1, lsl 2, 0, wait 0, 1, 1, 0
  12: 67 00 44 54 01 01 20 00 11 00 00 40 46 00  device_load      0, i32, x, r42, u2_u3, r1, lsl 2, 0, 1, 0, 0
  20: 9F 01 54 5A 02 02 08 8C 11 04              iadd             r45, 1, r1.cache
  2a: 9F 01 54 56 02 04 08 8C 11 04              iadd             r43, 2, r1.cache
  34: 9F 01 54 52 02 06 08 8C 11 04              iadd             r41, 3, r1.cache
  3e: 9F 01 54 4E 02 08 08 8C 11 04              iadd             r39, 4, r1.cache
  48: 9F 01 54 4A 02 0A 08 8C 11 04              iadd             r37, 5, r1.cache
  52: 9F 01 64 46 02 0C 08 8C 11 04              iadd.q2.todo     r35, 6, r1.cache
  5c: 9F 01 54 42 02 0E 08 8C 11 04              iadd             r33, 7, r1.cache
  66: 9F 01 54 3E 02 10 08 8C 11 04              iadd             r31, 8, r1.cache
  70: 9F 01 54 3A 02 12 08 8C 11 04              iadd             r29, 9, r1.cache
  7a: 9F 01 54 36 02 14 08 88 11 04              iadd             r27, 10, r1
  84: 67 00 54 50 02 01 20 00 11 00 00 40 46 00  device_load      0, i32, x, r40, u4_u5, r1, lsl 2, 0, 1, 1, 0
  92: 67 00 54 4C 00 2D 20 00 51 00 00 40 46 00  device_load      1, i32, x, r38, u0_u1, r45, lsl 2, 0, 1, 1, 0
  a0: 67 00 54 48 00 2B 20 00 51 00 00 40 46 00  device_load      1, i32, x, r36, u0_u1, r43, lsl 2, 0, 1, 1, 0
  ae: 67 00 54 44 00 29 20 00 51 00 00 40 46 00  device_load      1, i32, x, r34, u0_u1, r41, lsl 2, 0, 1, 1, 0
  bc: 67 00 54 40 00 27 20 00 51 00 00 40 46 00  device_load      1, i32, x, r32, u0_u1, r39, lsl 2, 0, 1, 1, 0
  ca: 67 00 54 3C 00 25 20 00 51 00 00 40 46 00  device_load      1, i32, x, r30, u0_u1, r37, lsl 2, 0, 1, 1, 0
  d8: 67 00 54 38 00 23 20 00 51 01 00 40 46 00  device_load      5, i32, x, r28, u0_u1, r35, lsl 2, 0, 1, 1, 0
  e6: 67 00 54 34 00 21 20 00 51 01 00 40 46 00  device_load      5, i32, x, r26, u0_u1, r33, lsl 2, 0, 1, 1, 0
  f4: 67 00 54 30 00 1F 20 00 51 01 00 40 46 00  device_load      5, i32, x, r24, u0_u1, r31, lsl 2, 0, 1, 1, 0
 102: 67 00 54 2C 00 1D 20 00 51 01 00 40 46 00  device_load      5, i32, x, r22, u0_u1, r29, lsl 2, 0, 1, 1, 0
 110: 67 00 44 06 00 1B 20 00 51 01 00 40 46 00  device_load      5, i32, x, r3, u0_u1, r27, lsl 2, 0, 1, 0, 0
 11e: 9F 01 54 32 02 16 08 8C 11 04              iadd             r25, 11, r1.cache
 128: 9F 01 54 2E 02 18 08 8C 11 04              iadd             r23, 12, r1.cache
 132: 9F 01 54 0A 02 1A 08 8C 11 04              iadd             r5, 13, r1.cache
 13c: 9F 01 54 2A 02 1C 08 8C 11 04              iadd             r21, 14, r1.cache
 146: 9F 01 54 26 02 1E 08 8C 11 04              iadd             r19, 15, r1.cache
 150: 9F 01 54 22 02 20 08 8C 11 04              iadd             r17, 16, r1.cache
 15a: 9F 01 64 1E 02 22 08 8C 11 04              iadd.q2.todo     r15, 17, r1.cache
 164: 9F 01 54 1A 02 24 08 8C 11 04              iadd             r13, 18, r1.cache
 16e: 9F 01 54 16 02 26 08 8C 11 04              iadd             r11, 19, r1.cache
 178: 9F 01 54 12 02 28 08 8C 11 04              iadd             r9, 20, r1.cache
 182: 9F 01 54 0E 02 2A 08 88 11 04              iadd             r7, 21, r1
 18c: 67 00 54 28 00 19 20 00 91 00 00 40 46 00  device_load      2, i32, x, r20, u0_u1, r25, lsl 2, 0, 1, 1, 0
 19a: 67 00 54 24 00 17 20 00 91 00 00 40 46 00  device_load      2, i32, x, r18, u0_u1, r23, lsl 2, 0, 1, 1, 0
 1a8: 67 00 54 20 00 05 20 00 91 00 00 40 46 00  device_load      2, i32, x, r16, u0_u1, r5, lsl 2, 0, 1, 1, 0
 1b6: 67 00 54 1C 00 15 20 00 91 00 00 40 46 00  device_load      2, i32, x, r14, u0_u1, r21, lsl 2, 0, 1, 1, 0
 1c4: 67 00 54 18 00 13 20 00 91 00 00 40 46 00  device_load      2, i32, x, r12, u0_u1, r19, lsl 2, 0, 1, 1, 0
 1d2: 67 00 54 14 00 11 20 00 91 00 00 40 46 00  device_load      2, i32, x, r10, u0_u1, r17, lsl 2, 0, 1, 1, 0
 1e0: 67 00 54 10 00 0F 20 00 91 00 00 40 46 00  device_load      2, i32, x, r8, u0_u1, r15, lsl 2, 0, 1, 1, 0
 1ee: 67 00 54 0C 00 0D 20 00 11 01 00 40 46 00  device_load      4, i32, x, r6, u0_u1, r13, lsl 2, 0, 1, 1, 0
 1fc: 67 00 54 08 00 0B 20 00 11 01 00 40 46 00  device_load      4, i32, x, r4, u0_u1, r11, lsl 2, 0, 1, 1, 0
 20a: 67 00 54 04 00 09 20 00 11 01 00 40 46 00  device_load      4, i32, x, r2, u0_u1, r9, lsl 2, 0, 1, 1, 0
 218: 67 00 44 00 00 07 20 00 D1 00 00 40 46 00  device_load      3, i32, x, r0, u0_u1, r7, lsl 2, 0, 1, 0, 0
 226: 9F 10 54 5E 02 A8 60 81 D2 21 2A 00        imadd            r47, r42, r44, r40, wait 0
 232: E7 00 54 5E 03 01 20 00 51 00 00 90 11 00  device_store     1, i32, x, r47, u6_u7, r1, lsl 2, 0, 1, 1
 240: E7 00 54 58 03 2D 21 00 51 00 00 90 11 00  device_store     1, i32, x, r44, u6_u7, r45.discard, lsl 2, 0, 1, 1
 24e: E7 00 54 54 03 2B 21 00 51 00 00 90 11 00  device_store     1, i32, x, r42, u6_u7, r43.discard, lsl 2, 0, 1, 1
 25c: E7 00 54 50 03 29 21 00 51 00 00 90 11 00  device_store     1, i32, x, r40, u6_u7, r41.discard, lsl 2, 0, 1, 1
 26a: E7 20 54 4C 03 27 21 00 51 00 00 90 11 00  device_store     1, i32, x, r38, u6_u7, r39.discard, lsl 2, 0, wait 1, 1, 1
 278: E7 00 54 48 03 25 21 00 51 00 00 90 11 00  device_store     1, i32, x, r36, u6_u7, r37.discard, lsl 2, 0, 1, 1
 286: E7 00 54 44 03 23 21 00 51 00 00 90 11 00  device_store     1, i32, x, r34, u6_u7, r35.discard, lsl 2, 0, 1, 1
 294: E7 00 54 40 03 21 21 00 51 00 00 90 11 00  device_store     1, i32, x, r32, u6_u7, r33.discard, lsl 2, 0, 1, 1
 2a2: E7 00 54 3C 03 1F 21 00 51 00 00 90 11 00  device_store     1, i32, x, r30, u6_u7, r31.discard, lsl 2, 0, 1, 1
 2b0: E7 00 56 38 03 1D 21 00 51 00 00 90 11 00  device_store     1, i32, x, r28, u6_u7, r29.discard, lsl 2, 0, wait 5, 1, 1
 2be: E7 00 54 34 03 1B 21 00 51 00 00 90 11 00  device_store     1, i32, x, r26, u6_u7, r27.discard, lsl 2, 0, 1, 1
 2cc: E7 00 54 30 03 19 21 00 51 00 00 90 11 00  device_store     1, i32, x, r24, u6_u7, r25.discard, lsl 2, 0, 1, 1
 2da: E7 00 54 2C 03 17 21 00 51 00 00 90 11 00  device_store     1, i32, x, r22, u6_u7, r23.discard, lsl 2, 0, 1, 1
 2e8: E7 00 54 06 03 05 21 00 51 00 00 90 11 00  device_store     1, i32, x, r3, u6_u7, r5.discard, lsl 2, 0, 1, 1
 2f6: 9F 01 54 0A 02 2C 08 8C 11 04              iadd             r5, 22, r1.cache
 300: 9F 01 54 06 02 2E 08 8C 11 04              iadd             r3, 23, r1.cache
 30a: 9F 01 54 02 02 30 08 88 15 04              iadd             r1, 24, r1.discard
 314: E7 40 54 28 03 15 21 00 51 00 00 90 11 00  device_store     1, i32, x, r20, u6_u7, r21.discard, lsl 2, 0, wait 2, 1, 1
 322: E7 00 54 24 03 13 21 00 11 00 00 90 11 00  device_store     0, i32, x, r18, u6_u7, r19.discard, lsl 2, 0, 1, 1
 330: E7 00 54 20 03 11 21 00 11 00 00 90 11 00  device_store     0, i32, x, r16, u6_u7, r17.discard, lsl 2, 0, 1, 1
 33e: E7 00 54 1C 03 0F 21 00 11 00 00 90 11 00  device_store     0, i32, x, r14, u6_u7, r15.discard, lsl 2, 0, 1, 1
 34c: E7 00 54 18 03 0D 21 00 11 00 00 90 11 00  device_store     0, i32, x, r12, u6_u7, r13.discard, lsl 2, 0, 1, 1
 35a: E7 00 54 14 03 0B 21 00 11 00 00 90 11 00  device_store     0, i32, x, r10, u6_u7, r11.discard, lsl 2, 0, 1, 1
 368: E7 00 54 10 03 09 21 00 11 00 00 90 11 00  device_store     0, i32, x, r8, u6_u7, r9.discard, lsl 2, 0, 1, 1
 376: E7 00 55 0C 03 07 21 00 11 00 00 90 11 00  device_store     0, i32, x, r6, u6_u7, r7.discard, lsl 2, 0, wait 4, 1, 1
 384: E7 00 54 08 03 05 21 00 11 00 00 90 11 00  device_store     0, i32, x, r4, u6_u7, r5.discard, lsl 2, 0, 1, 1
 392: E7 00 54 04 03 03 21 00 11 00 00 90 11 00  device_store     0, i32, x, r2, u6_u7, r3.discard, lsl 2, 0, 1, 1
 3a0: E7 80 54 00 03 01 21 00 11 00 00 90 11 00  device_store     0, i32, x, r0, u6_u7, r1.discard, lsl 2, 0, wait 3, 1, 1
 3ae: 0E 00 00 00                                stop             
