   0: 1C A0 10 06                                get_sr           0, r1, sr32 (thread_position_in_grid.x)
   4: 67 10 44 80 00 01 20 00 11 00 00 40 46 00  device_load      0, i32, x, r64, u0_u1, r1, lsl 2, 0, wait 0, 1, 0, 0
  12: 9F 01 54 82 02 02 08 8C 11 04              iadd             r65, 1, r1.cache
  1c: 9F 01 54 7E 02 04 08 8C 11 04              iadd             r63, 2, r1.cache
  26: 9F 01 54 7A 02 06 08 8C 11 04              iadd             r61, 3, r1.cache
  30: 9F 01 54 76 02 08 08 8C 11 04              iadd             r59, 4, r1.cache
  3a: 9F 01 64 72 02 0A 08 8C 11 04              iadd.q2.todo     r57, 5, r1.cache
  44: 9F 01 54 6E 02 0C 08 8C 11 04              iadd             r55, 6, r1.cache
  4e: 9F 01 54 6A 02 0E 08 8C 11 04              iadd             r53, 7, r1.cache
  58: 9F 01 54 66 02 10 08 8C 11 04              iadd             r51, 8, r1.cache
  62: 9F 01 54 62 02 12 08 88 11 04              iadd             r49, 9, r1
  6c: 67 00 54 7C 01 01 20 00 11 00 00 40 46 00  device_load      0, i32, x, r62, u2_u3, r1, lsl 2, 0, 1, 1, 0
  7a: 67 00 54 78 02 01 20 00 11 00 00 40 46 00  device_load      0, i32, x, r60, u4_u5, r1, lsl 2, 0, 1, 1, 0
  88: 67 00 54 74 00 41 20 00 11 00 00 40 46 00  device_load      0, i32, x, r58, u0_u1, r65, lsl 2, 0, 1, 1, 0
  96: 67 00 54 70 00 3F 20 00 11 00 00 40 46 00  device_load      0, i32, x, r56, u0_u1, r63, lsl 2, 0, 1, 1, 0
  a4: 67 00 54 6C 00 3D 20 00 11 00 00 40 46 00  device_load      0, i32, x, r54, u0_u1, r61, lsl 2, 0, 1, 1, 0
  b2: 67 00 54 68 00 3B 20 00 11 00 00 40 46 00  device_load      0, i32, x, r52, u0_u1, r59, lsl 2, 0, 1, 1, 0
  c0: 67 00 54 64 00 39 20 00 11 00 00 40 46 00  device_load      0, i32, x, r50, u0_u1, r57, lsl 2, 0, 1, 1, 0
  ce: 67 00 54 60 00 37 20 00 11 00 00 40 46 00  device_load      0, i32, x, r48, u0_u1, r55, lsl 2, 0, 1, 1, 0
  dc: 67 00 54 5C 00 35 20 00 11 00 00 40 46 00  device_load      0, i32, x, r46, u0_u1, r53, lsl 2, 0, 1, 1, 0
  ea: 67 00 54 58 00 33 20 00 11 00 00 40 46 00  device_load      0, i32, x, r44, u0_u1, r51, lsl 2, 0, 1, 1, 0
  f8: 67 00 44 54 00 31 20 00 11 00 00 40 46 00  device_load      0, i32, x, r42, u0_u1, r49, lsl 2, 0, 1, 0, 0
 106: 9F 01 54 5E 02 14 08 8C 11 04              iadd             r47, 10, r1.cache
 110: 9F 01 54 5A 02 16 08 8C 11 04              iadd             r45, 11, r1.cache
 11a: 9F 01 54 56 02 18 08 8C 11 04              iadd             r43, 12, r1.cache
 124: 9F 01 54 52 02 1A 08 8C 11 04              iadd             r41, 13, r1.cache
 12e: 9F 01 54 4E 02 1C 08 8C 11 04              iadd             r39, 14, r1.cache
 138: 9F 01 54 4A 02 1E 08 8C 11 04              iadd             r37, 15, r1.cache
 142: 9F 01 64 46 02 20 08 8C 11 04              iadd.q2.todo     r35, 16, r1.cache
 14c: 9F 01 54 42 02 22 08 8C 11 04              iadd             r33, 17, r1.cache
 156: 9F 01 54 3E 02 24 08 8C 11 04              iadd             r31, 18, r1.cache
 160: 9F 01 54 3A 02 26 08 8C 11 04              iadd             r29, 19, r1.cache
 16a: 9F 01 54 36 02 28 08 8C 11 04              iadd             r27, 20, r1.cache
 174: 67 00 54 50 00 2F 20 00 11 00 00 40 46 00  device_load      0, i32, x, r40, u0_u1, r47, lsl 2, 0, 1, 1, 0
 182: 67 00 54 4C 00 2D 20 00 11 00 00 40 46 00  device_load      0, i32, x, r38, u0_u1, r45, lsl 2, 0, 1, 1, 0
 190: 67 00 54 48 00 2B 20 00 11 00 00 40 46 00  device_load      0, i32, x, r36, u0_u1, r43, lsl 2, 0, 1, 1, 0
 19e: 67 00 54 44 00 29 20 00 91 00 00 40 46 00  device_load      2, i32, x, r34, u0_u1, r41, lsl 2, 0, 1, 1, 0
 1ac: 67 00 54 40 00 27 20 00 91 00 00 40 46 00  device_load      2, i32, x, r32, u0_u1, r39, lsl 2, 0, 1, 1, 0
 1ba: 67 00 54 3C 00 25 20 00 91 00 00 40 46 00  device_load      2, i32, x, r30, u0_u1, r37, lsl 2, 0, 1, 1, 0
 1c8: 67 00 54 38 00 23 20 00 91 00 00 40 46 00  device_load      2, i32, x, r28, u0_u1, r35, lsl 2, 0, 1, 1, 0
 1d6: 67 00 54 34 00 21 20 00 91 00 00 40 46 00  device_load      2, i32, x, r26, u0_u1, r33, lsl 2, 0, 1, 1, 0
 1e4: 67 00 54 30 00 1F 20 00 91 00 00 40 46 00  device_load      2, i32, x, r24, u0_u1, r31, lsl 2, 0, 1, 1, 0
 1f2: 67 00 54 2C 00 1D 20 00 91 00 00 40 46 00  device_load      2, i32, x, r22, u0_u1, r29, lsl 2, 0, 1, 1, 0
 200: 67 00 44 06 00 1B 20 00 11 01 00 40 46 00  device_load      4, i32, x, r3, u0_u1, r27, lsl 2, 0, 1, 0, 0
 20e: 9F 01 54 32 02 2A 08 8C 11 04              iadd             r25, 21, r1.cache
 218: 9F 01 54 2E 02 2C 08 8C 11 04              iadd             r23, 22, r1.cache
 222: 9F 01 54 0A 02 2E 08 8C 11 04              iadd             r5, 23, r1.cache
 22c: 9F 01 54 2A 02 30 08 8C 11 04              iadd             r21, 24, r1.cache
 236: 9F 01 54 26 02 32 08 8C 11 04              iadd             r19, 25, r1.cache
 240: 9F 01 54 22 02 34 08 8C 11 04              iadd             r17, 26, r1.cache
 24a: 9F 01 64 1E 02 36 08 8C 11 04              iadd.q2.todo     r15, 27, r1.cache
 254: 9F 01 54 1A 02 38 08 8C 11 04              iadd             r13, 28, r1.cache
 25e: 9F 01 54 16 02 3A 08 8C 11 04              iadd             r11, 29, r1.cache
 268: 9F 01 54 12 02 3C 08 8C 11 04              iadd             r9, 30, r1.cache
 272: 9F 01 54 0E 02 3E 08 88 11 04              iadd             r7, 31, r1
 27c: 67 00 54 28 00 19 20 00 11 01 00 40 46 00  device_load      4, i32, x, r20, u0_u1, r25, lsl 2, 0, 1, 1, 0
 28a: 67 00 54 24 00 17 20 00 11 01 00 40 46 00  device_load      4, i32, x, r18, u0_u1, r23, lsl 2, 0, 1, 1, 0
 298: 67 00 54 20 00 05 20 00 D1 00 00 40 46 00  device_load      3, i32, x, r16, u0_u1, r5, lsl 2, 0, 1, 1, 0
 2a6: 67 00 54 1C 00 15 20 00 D1 00 00 40 46 00  device_load      3, i32, x, r14, u0_u1, r21, lsl 2, 0, 1, 1, 0
 2b4: 67 00 54 18 00 13 20 00 D1 00 00 40 46 00  device_load      3, i32, x, r12, u0_u1, r19, lsl 2, 0, 1, 1, 0
 2c2: 67 00 54 14 00 11 20 00 D1 00 00 40 46 00  device_load      3, i32, x, r10, u0_u1, r17, lsl 2, 0, 1, 1, 0
 2d0: 67 00 54 10 00 0F 20 00 D1 00 00 40 46 00  device_load      3, i32, x, r8, u0_u1, r15, lsl 2, 0, 1, 1, 0
 2de: 67 00 54 0C 00 0D 20 00 D1 00 00 40 46 00  device_load      3, i32, x, r6, u0_u1, r13, lsl 2, 0, 1, 1, 0
 2ec: 67 00 54 08 00 0B 20 00 51 01 00 40 46 00  device_load      5, i32, x, r4, u0_u1, r11, lsl 2, 0, 1, 1, 0
 2fa: 67 00 54 04 00 09 20 00 51 01 00 40 46 00  device_load      5, i32, x, r2, u0_u1, r9, lsl 2, 0, 1, 1, 0
 308: 67 00 44 00 00 07 20 00 51 00 00 40 46 00  device_load      1, i32, x, r0, u0_u1, r7, lsl 2, 0, 1, 0, 0
 316: 9F 10 54 84 02 F8 00 C2 D3 21 2A 00        imadd            r66, r62, r64, r60, wait 0
 322: E7 00 54 84 03 01 20 00 51 00 00 90 11 00  device_store     1, i32, x, r66, u6_u7, r1, lsl 2, 0, 1, 1
 330: E7 00 54 80 03 41 21 00 51 00 00 90 11 00  device_store     1, i32, x, r64, u6_u7, r65.discard, lsl 2, 0, 1, 1
 33e: E7 00 54 7C 03 3F 21 00 51 00 00 90 11 00  device_store     1, i32, x, r62, u6_u7, r63.discard, lsl 2, 0, 1, 1
 34c: E7 00 54 78 03 3D 21 00 51 00 00 90 11 00  device_store     1, i32, x, r60, u6_u7, r61.discard, lsl 2, 0, 1, 1
 35a: E7 00 54 74 03 3B 21 00 51 00 00 90 11 00  device_store     1, i32, x, r58, u6_u7, r59.discard, lsl 2, 0, 1, 1
 368: E7 00 54 70 03 39 21 00 51 00 00 90 11 00  device_store     1, i32, x, r56, u6_u7, r57.discard, lsl 2, 0, 1, 1
 376: E7 00 54 6C 03 37 21 00 51 00 00 90 11 00  device_store     1, i32, x, r54, u6_u7, r55.discard, lsl 2, 0, 1, 1
 384: E7 00 54 68 03 35 21 00 51 00 00 90 11 00  device_store     1, i32, x, r52, u6_u7, r53.discard, lsl 2, 0, 1, 1
 392: E7 00 54 64 03 33 21 00 51 00 00 90 11 00  device_store     1, i32, x, r50, u6_u7, r51.discard, lsl 2, 0, 1, 1
 3a0: E7 00 54 60 03 31 21 00 51 00 00 90 11 00  device_store     1, i32, x, r48, u6_u7, r49.discard, lsl 2, 0, 1, 1
 3ae: E7 00 54 5C 03 2F 21 00 51 00 00 90 11 00  device_store     1, i32, x, r46, u6_u7, r47.discard, lsl 2, 0, 1, 1
 3bc: E7 00 54 58 03 2D 21 00 51 00 00 90 11 00  device_store     1, i32, x, r44, u6_u7, r45.discard, lsl 2, 0, 1, 1
 3ca: E7 00 54 54 03 2B 21 00 51 00 00 90 11 00  device_store     1, i32, x, r42, u6_u7, r43.discard, lsl 2, 0, 1, 1
 3d8: E7 00 54 50 03 29 21 00 51 00 00 90 11 00  device_store     1, i32, x, r40, u6_u7, r41.discard, lsl 2, 0, 1, 1
 3e6: E7 00 54 4C 03 27 21 00 51 00 00 90 11 00  device_store     1, i32, x, r38, u6_u7, r39.discard, lsl 2, 0, 1, 1
 3f4: E7 00 54 48 03 25 21 00 51 00 00 90 11 00  device_store     1, i32, x, r36, u6_u7, r37.discard, lsl 2, 0, 1, 1
 402: E7 40 54 44 03 23 21 00 51 00 00 90 11 00  device_store     1, i32, x, r34, u6_u7, r35.discard, lsl 2, 0, wait 2, 1, 1
 410: E7 00 54 40 03 21 21 00 51 00 00 90 11 00  device_store     1, i32, x, r32, u6_u7, r33.discard, lsl 2, 0, 1, 1
 41e: E7 00 54 3C 03 1F 21 00 51 00 00 90 11 00  device_store     1, i32, x, r30, u6_u7, r31.discard, lsl 2, 0, 1, 1
 42c: E7 00 54 38 03 1D 21 00 51 00 00 90 11 00  device_store     1, i32, x, r28, u6_u7, r29.discard, lsl 2, 0, 1, 1
 43a: E7 00 54 34 03 1B 21 00 51 00 00 90 11 00  device_store     1, i32, x, r26, u6_u7, r27.discard, lsl 2, 0, 1, 1
 448: E7 00 54 30 03 19 21 00 51 00 00 90 11 00  device_store     1, i32, x, r24, u6_u7, r25.discard, lsl 2, 0, 1, 1
 456: E7 00 54 2C 03 17 21 00 51 00 00 90 11 00  device_store     1, i32, x, r22, u6_u7, r23.discard, lsl 2, 0, 1, 1
 464: E7 00 55 06 03 05 21 00 51 00 00 90 11 00  device_store     1, i32, x, r3, u6_u7, r5.discard, lsl 2, 0, wait 4, 1, 1
 472: 9F 01 54 0A 02 40 08 8C 11 04              iadd             r5, 32, r1.cache
 47c: 9F 01 54 06 02 42 08 8C 11 04              iadd             r3, 33, r1.cache
 486: 9F 01 54 02 02 44 08 88 15 04              iadd             r1, 34, r1.discard
 490: E7 00 54 28 03 15 21 00 51 00 00 90 11 00  device_store     1, i32, x, r20, u6_u7, r21.discard, lsl 2, 0, 1, 1
 49e: E7 00 54 24 03 13 21 00 11 00 00 90 11 00  device_store     0, i32, x, r18, u6_u7, r19.discard, lsl 2, 0, 1, 1
 4ac: E7 80 54 20 03 11 21 00 11 00 00 90 11 00  device_store     0, i32, x, r16, u6_u7, r17.discard, lsl 2, 0, wait 3, 1, 1
 4ba: E7 00 54 1C 03 0F 21 00 11 00 00 90 11 00  device_store     0, i32, x, r14, u6_u7, r15.discard, lsl 2, 0, 1, 1
 4c8: E7 00 54 18 03 0D 21 00 11 00 00 90 11 00  device_store     0, i32, x, r12, u6_u7, r13.discard, lsl 2, 0, 1, 1
 4d6: E7 00 54 14 03 0B 21 00 11 00 00 90 11 00  device_store     0, i32, x, r10, u6_u7, r11.discard, lsl 2, 0, 1, 1
 4e4: E7 00 54 10 03 09 21 00 11 00 00 90 11 00  device_store     0, i32, x, r8, u6_u7, r9.discard, lsl 2, 0, 1, 1
 4f2: E7 00 54 0C 03 07 21 00 11 00 00 90 11 00  device_store     0, i32, x, r6, u6_u7, r7.discard, lsl 2, 0, 1, 1
 500: E7 00 56 08 03 05 21 00 11 00 00 90 11 00  device_store     0, i32, x, r4, u6_u7, r5.discard, lsl 2, 0, wait 5, 1, 1
 50e: E7 00 54 04 03 03 21 00 11 00 00 90 11 00  device_store     0, i32, x, r2, u6_u7, r3.discard, lsl 2, 0, 1, 1
 51c: E7 20 54 00 03 01 21 00 11 00 00 90 11 00  device_store     0, i32, x, r0, u6_u7, r1.discard, lsl 2, 0, wait 1, 1, 1
 52a: 0E 00 00 00                                stop             
