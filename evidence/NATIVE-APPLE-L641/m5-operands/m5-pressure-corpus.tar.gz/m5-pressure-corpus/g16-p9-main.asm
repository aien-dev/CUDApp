   0: 1C A0 10 06                                get_sr           0, r1, sr32 (thread_position_in_grid.x)
   4: 67 10 54 2C 00 01 20 00 51 01 00 40 46 00  device_load      5, i32, x, r22, u0_u1, r1, lsl 2, 0, wait 0, 1, 1, 0
  12: 67 00 54 28 01 01 20 00 51 01 00 40 46 00  device_load      5, i32, x, r20, u2_u3, r1, lsl 2, 0, 1, 1, 0
  20: 67 00 44 24 02 01 20 00 51 01 00 40 46 00  device_load      5, i32, x, r18, u4_u5, r1, lsl 2, 0, 1, 0, 0
  2e: 9F 01 54 06 02 02 08 8C 11 04              iadd             r3, 1, r1.cache
  38: 9F 01 54 2A 02 04 08 8C 11 04              iadd             r21, 2, r1.cache
  42: 9F 01 54 26 02 06 08 8C 11 04              iadd             r19, 3, r1.cache
  4c: 9F 01 54 22 02 08 08 8C 11 04              iadd             r17, 4, r1.cache
  56: 9F 01 64 1E 02 0A 08 8C 11 04              iadd.q2.todo     r15, 5, r1.cache
  60: 9F 01 54 1A 02 0C 08 8C 11 04              iadd             r13, 6, r1.cache
  6a: 9F 01 54 16 02 0E 08 8C 11 04              iadd             r11, 7, r1.cache
  74: 9F 01 54 12 02 10 08 8C 11 04              iadd             r9, 8, r1.cache
  7e: 9F 01 54 0E 02 12 08 88 11 04              iadd             r7, 9, r1
  88: 67 00 54 20 00 03 20 00 11 00 00 40 46 00  device_load      0, i32, x, r16, u0_u1, r3, lsl 2, 0, 1, 1, 0
  96: 67 00 54 1C 00 15 20 00 51 00 00 40 46 00  device_load      1, i32, x, r14, u0_u1, r21, lsl 2, 0, 1, 1, 0
  a4: 67 00 54 18 00 13 20 00 51 00 00 40 46 00  device_load      1, i32, x, r12, u0_u1, r19, lsl 2, 0, 1, 1, 0
  b2: 67 00 54 14 00 11 20 00 51 00 00 40 46 00  device_load      1, i32, x, r10, u0_u1, r17, lsl 2, 0, 1, 1, 0
  c0: 67 00 54 10 00 0F 20 00 51 00 00 40 46 00  device_load      1, i32, x, r8, u0_u1, r15, lsl 2, 0, 1, 1, 0
  ce: 67 00 54 0C 00 0D 20 00 11 01 00 40 46 00  device_load      4, i32, x, r6, u0_u1, r13, lsl 2, 0, 1, 1, 0
  dc: 67 00 54 08 00 0B 20 00 11 01 00 40 46 00  device_load      4, i32, x, r4, u0_u1, r11, lsl 2, 0, 1, 1, 0
  ea: 67 00 54 04 00 09 20 00 D1 00 00 40 46 00  device_load      3, i32, x, r2, u0_u1, r9, lsl 2, 0, 1, 1, 0
  f8: 67 00 44 00 00 07 20 00 91 00 00 40 46 00  device_load      2, i32, x, r0, u0_u1, r7, lsl 2, 0, 1, 0, 0
 106: 9F 00 56 0A 02 50 B0 20 D1 21 2A 00        imadd            r5, r20, r22, r18, wait 5
 112: E7 00 54 0A 03 01 20 00 51 00 00 90 11 00  device_store     1, i32, x, r5, u6_u7, r1, lsl 2, 0, 1, 1
 120: E7 00 54 2C 03 03 21 00 51 00 00 90 11 00  device_store     1, i32, x, r22, u6_u7, r3.discard, lsl 2, 0, 1, 1
 12e: 9F 01 54 0A 02 14 08 8C 11 04              iadd             r5, 10, r1.cache
 138: 9F 01 54 06 02 16 08 8C 11 04              iadd             r3, 11, r1.cache
 142: 9F 01 54 02 02 18 08 88 15 04              iadd             r1, 12, r1.discard
 14c: E7 00 54 28 03 15 21 00 51 00 00 90 11 00  device_store     1, i32, x, r20, u6_u7, r21.discard, lsl 2, 0, 1, 1
 15a: E7 00 54 24 03 13 21 00 11 00 00 90 11 00  device_store     0, i32, x, r18, u6_u7, r19.discard, lsl 2, 0, 1, 1
 168: E7 10 54 20 03 11 21 00 11 00 00 90 11 00  device_store     0, i32, x, r16, u6_u7, r17.discard, lsl 2, 0, wait 0, 1, 1
 176: E7 20 54 1C 03 0F 21 00 11 00 00 90 11 00  device_store     0, i32, x, r14, u6_u7, r15.discard, lsl 2, 0, wait 1, 1, 1
 184: E7 00 54 18 03 0D 21 00 11 00 00 90 11 00  device_store     0, i32, x, r12, u6_u7, r13.discard, lsl 2, 0, 1, 1
 192: E7 00 54 14 03 0B 21 00 11 00 00 90 11 00  device_store     0, i32, x, r10, u6_u7, r11.discard, lsl 2, 0, 1, 1
 1a0: E7 00 54 10 03 09 21 00 11 00 00 90 11 00  device_store     0, i32, x, r8, u6_u7, r9.discard, lsl 2, 0, 1, 1
 1ae: E7 00 55 0C 03 07 21 00 11 00 00 90 11 00  device_store     0, i32, x, r6, u6_u7, r7.discard, lsl 2, 0, wait 4, 1, 1
 1bc: E7 00 54 08 03 05 21 00 11 00 00 90 11 00  device_store     0, i32, x, r4, u6_u7, r5.discard, lsl 2, 0, 1, 1
 1ca: E7 80 54 04 03 03 21 00 11 00 00 90 11 00  device_store     0, i32, x, r2, u6_u7, r3.discard, lsl 2, 0, wait 3, 1, 1
 1d8: E7 40 54 00 03 01 21 00 11 00 00 90 11 00  device_store     0, i32, x, r0, u6_u7, r1.discard, lsl 2, 0, wait 2, 1, 1
 1e6: 0E 00 00 00                                stop             
