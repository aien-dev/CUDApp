   0: 1C A0 10 06                                get_sr           0, r1, sr32 (thread_position_in_grid.x)
   4: 9F 11 54 76 02 02 08 8C 11 04              iadd             r59, 1, r1.cache, wait 0
   e: 9F 01 64 72 02 04 08 8C 11 04              iadd.q2.todo     r57, 2, r1.cache
  18: 9F 01 54 6E 02 06 08 8C 11 04              iadd             r55, 3, r1.cache
  22: 9F 01 54 6A 02 08 08 8C 11 04              iadd             r53, 4, r1.cache
  2c: 9F 01 54 66 02 0A 08 8C 11 04              iadd             r51, 5, r1.cache
  36: 9F 01 54 62 02 0C 08 88 11 04              iadd             r49, 6, r1
  40: 67 00 54 74 00 01 20 00 11 00 00 40 46 00  device_load      0, i32, x, r58, u0_u1, r1, lsl 2, 0, 1, 1, 0
  4e: 67 00 54 70 01 01 20 00 11 00 00 40 46 00  device_load      0, i32, x, r56, u2_u3, r1, lsl 2, 0, 1, 1, 0
  5c: 67 00 54 6C 02 01 20 00 11 00 00 40 46 00  device_load      0, i32, x, r54, u4_u5, r1, lsl 2, 0, 1, 1, 0
  6a: 67 00 54 68 00 3B 20 00 51 00 00 40 46 00  device_load      1, i32, x, r52, u0_u1, r59, lsl 2, 0, 1, 1, 0
  78: 67 00 54 64 00 39 20 00 51 00 00 40 46 00  device_load      1, i32, x, r50, u0_u1, r57, lsl 2, 0, 1, 1, 0
  86: 67 00 54 60 00 37 20 00 51 00 00 40 46 00  device_load      1, i32, x, r48, u0_u1, r55, lsl 2, 0, 1, 1, 0
  94: 67 00 54 5C 00 35 20 00 51 00 00 40 46 00  device_load      1, i32, x, r46, u0_u1, r53, lsl 2, 0, 1, 1, 0
  a2: 67 00 54 58 00 33 20 00 51 00 00 40 46 00  device_load      1, i32, x, r44, u0_u1, r51, lsl 2, 0, 1, 1, 0
  b0: 67 00 44 54 00 31 20 00 51 00 00 40 46 00  device_load      1, i32, x, r42, u0_u1, r49, lsl 2, 0, 1, 0, 0
  be: 9F 01 54 5E 02 0E 08 8C 11 04              iadd             r47, 7, r1.cache
  c8: 9F 01 54 5A 02 10 08 8C 11 04              iadd             r45, 8, r1.cache
  d2: 9F 01 54 56 02 12 08 8C 11 04              iadd             r43, 9, r1.cache
  dc: 9F 01 54 52 02 14 08 8C 11 04              iadd             r41, 10, r1.cache
  e6: 9F 01 54 4E 02 16 08 8C 11 04              iadd             r39, 11, r1.cache
  f0: 9F 01 54 4A 02 18 08 8C 11 04              iadd             r37, 12, r1.cache
  fa: 9F 01 64 46 02 1A 08 8C 11 04              iadd.q2.todo     r35, 13, r1.cache
 104: 9F 01 54 42 02 1C 08 8C 11 04              iadd             r33, 14, r1.cache
 10e: 9F 01 54 3E 02 1E 08 8C 11 04              iadd             r31, 15, r1.cache
 118: 9F 01 54 3A 02 20 08 8C 11 04              iadd             r29, 16, r1.cache
 122: 9F 01 54 36 02 22 08 8C 11 04              iadd             r27, 17, r1.cache
 12c: 67 00 54 50 00 2F 20 00 51 00 00 40 46 00  device_load      1, i32, x, r40, u0_u1, r47, lsl 2, 0, 1, 1, 0
 13a: 67 00 54 4C 00 2D 20 00 51 00 00 40 46 00  device_load      1, i32, x, r38, u0_u1, r45, lsl 2, 0, 1, 1, 0
 148: 67 00 54 48 00 2B 20 00 51 00 00 40 46 00  device_load      1, i32, x, r36, u0_u1, r43, lsl 2, 0, 1, 1, 0
 156: 67 00 54 44 00 29 20 00 51 00 00 40 46 00  device_load      1, i32, x, r34, u0_u1, r41, lsl 2, 0, 1, 1, 0
 164: 67 00 54 40 00 27 20 00 51 00 00 40 46 00  device_load      1, i32, x, r32, u0_u1, r39, lsl 2, 0, 1, 1, 0
 172: 67 00 54 3C 00 25 20 00 51 00 00 40 46 00  device_load      1, i32, x, r30, u0_u1, r37, lsl 2, 0, 1, 1, 0
 180: 67 00 54 38 00 23 20 00 91 00 00 40 46 00  device_load      2, i32, x, r28, u0_u1, r35, lsl 2, 0, 1, 1, 0
 18e: 67 00 54 34 00 21 20 00 91 00 00 40 46 00  device_load      2, i32, x, r26, u0_u1, r33, lsl 2, 0, 1, 1, 0
 19c: 67 00 54 30 00 1F 20 00 91 00 00 40 46 00  device_load      2, i32, x, r24, u0_u1, r31, lsl 2, 0, 1, 1, 0
 1aa: 67 00 54 2C 00 1D 20 00 91 00 00 40 46 00  device_load      2, i32, x, r22, u0_u1, r29, lsl 2, 0, 1, 1, 0
 1b8: 67 00 44 06 00 1B 20 00 91 00 00 40 46 00  device_load      2, i32, x, r3, u0_u1, r27, lsl 2, 0, 1, 0, 0
 1c6: 9F 01 54 32 02 24 08 8C 11 04              iadd             r25, 18, r1.cache
 1d0: 9F 01 54 2E 02 26 08 8C 11 04              iadd             r23, 19, r1.cache
 1da: 9F 01 54 0A 02 28 08 8C 11 04              iadd             r5, 20, r1.cache
 1e4: 9F 01 54 2A 02 2A 08 8C 11 04              iadd             r21, 21, r1.cache
 1ee: 9F 01 54 26 02 2C 08 8C 11 04              iadd             r19, 22, r1.cache
 1f8: 9F 01 54 22 02 2E 08 8C 11 04              iadd             r17, 23, r1.cache
 202: 9F 01 64 1E 02 30 08 8C 11 04              iadd.q2.todo     r15, 24, r1.cache
 20c: 9F 01 54 1A 02 32 08 8C 11 04              iadd             r13, 25, r1.cache
 216: 9F 01 54 16 02 34 08 8C 11 04              iadd             r11, 26, r1.cache
 220: 9F 01 54 12 02 36 08 8C 11 04              iadd             r9, 27, r1.cache
 22a: 9F 01 54 0E 02 38 08 88 11 04              iadd             r7, 28, r1
 234: 67 00 54 28 00 19 20 00 11 01 00 40 46 00  device_load      4, i32, x, r20, u0_u1, r25, lsl 2, 0, 1, 1, 0
 242: 67 00 54 24 00 17 20 00 11 01 00 40 46 00  device_load      4, i32, x, r18, u0_u1, r23, lsl 2, 0, 1, 1, 0
 250: 67 00 54 20 00 05 20 00 11 01 00 40 46 00  device_load      4, i32, x, r16, u0_u1, r5, lsl 2, 0, 1, 1, 0
 25e: 67 00 54 1C 00 15 20 00 11 01 00 40 46 00  device_load      4, i32, x, r14, u0_u1, r21, lsl 2, 0, 1, 1, 0
 26c: 67 00 54 18 00 13 20 00 11 01 00 40 46 00  device_load      4, i32, x, r12, u0_u1, r19, lsl 2, 0, 1, 1, 0
 27a: 67 00 54 14 00 11 20 00 11 01 00 40 46 00  device_load      4, i32, x, r10, u0_u1, r17, lsl 2, 0, 1, 1, 0
 288: 67 00 54 10 00 0F 20 00 D1 00 00 40 46 00  device_load      3, i32, x, r8, u0_u1, r15, lsl 2, 0, 1, 1, 0
 296: 67 00 54 0C 00 0D 20 00 D1 00 00 40 46 00  device_load      3, i32, x, r6, u0_u1, r13, lsl 2, 0, 1, 1, 0
 2a4: 67 00 54 08 00 0B 20 00 D1 00 00 40 46 00  device_load      3, i32, x, r4, u0_u1, r11, lsl 2, 0, 1, 1, 0
 2b2: 67 00 54 04 00 09 20 00 D1 00 00 40 46 00  device_load      3, i32, x, r2, u0_u1, r9, lsl 2, 0, 1, 1, 0
 2c0: 67 00 44 00 00 07 20 00 51 01 00 40 46 00  device_load      5, i32, x, r0, u0_u1, r7, lsl 2, 0, 1, 0, 0
 2ce: 9F 10 54 78 02 E0 D0 61 D3 21 2A 00        imadd            r60, r56, r58, r54, wait 0
 2da: E7 00 54 78 03 01 20 00 51 00 00 90 11 00  device_store     1, i32, x, r60, u6_u7, r1, lsl 2, 0, 1, 1
 2e8: E7 00 54 74 03 3B 21 00 51 00 00 90 11 00  device_store     1, i32, x, r58, u6_u7, r59.discard, lsl 2, 0, 1, 1
 2f6: E7 00 54 70 03 39 21 00 51 00 00 90 11 00  device_store     1, i32, x, r56, u6_u7, r57.discard, lsl 2, 0, 1, 1
 304: E7 00 54 6C 03 37 21 00 51 00 00 90 11 00  device_store     1, i32, x, r54, u6_u7, r55.discard, lsl 2, 0, 1, 1
 312: E7 20 54 68 03 35 21 00 51 00 00 90 11 00  device_store     1, i32, x, r52, u6_u7, r53.discard, lsl 2, 0, wait 1, 1, 1
 320: E7 00 54 64 03 33 21 00 51 00 00 90 11 00  device_store     1, i32, x, r50, u6_u7, r51.discard, lsl 2, 0, 1, 1
 32e: E7 00 54 60 03 31 21 00 51 00 00 90 11 00  device_store     1, i32, x, r48, u6_u7, r49.discard, lsl 2, 0, 1, 1
 33c: E7 00 54 5C 03 2F 21 00 51 00 00 90 11 00  device_store     1, i32, x, r46, u6_u7, r47.discard, lsl 2, 0, 1, 1
 34a: E7 00 54 58 03 2D 21 00 51 00 00 90 11 00  device_store     1, i32, x, r44, u6_u7, r45.discard, lsl 2, 0, 1, 1
 358: E7 00 54 54 03 2B 21 00 51 00 00 90 11 00  device_store     1, i32, x, r42, u6_u7, r43.discard, lsl 2, 0, 1, 1
 366: E7 00 54 50 03 29 21 00 51 00 00 90 11 00  device_store     1, i32, x, r40, u6_u7, r41.discard, lsl 2, 0, 1, 1
 374: E7 00 54 4C 03 27 21 00 51 00 00 90 11 00  device_store     1, i32, x, r38, u6_u7, r39.discard, lsl 2, 0, 1, 1
 382: E7 00 54 48 03 25 21 00 51 00 00 90 11 00  device_store     1, i32, x, r36, u6_u7, r37.discard, lsl 2, 0, 1, 1
 390: E7 00 54 44 03 23 21 00 51 00 00 90 11 00  device_store     1, i32, x, r34, u6_u7, r35.discard, lsl 2, 0, 1, 1
 39e: E7 00 54 40 03 21 21 00 51 00 00 90 11 00  device_store     1, i32, x, r32, u6_u7, r33.discard, lsl 2, 0, 1, 1
 3ac: E7 00 54 3C 03 1F 21 00 51 00 00 90 11 00  device_store     1, i32, x, r30, u6_u7, r31.discard, lsl 2, 0, 1, 1
 3ba: E7 40 54 38 03 1D 21 00 51 00 00 90 11 00  device_store     1, i32, x, r28, u6_u7, r29.discard, lsl 2, 0, wait 2, 1, 1
 3c8: E7 00 54 34 03 1B 21 00 51 00 00 90 11 00  device_store     1, i32, x, r26, u6_u7, r27.discard, lsl 2, 0, 1, 1
 3d6: E7 00 54 30 03 19 21 00 51 00 00 90 11 00  device_store     1, i32, x, r24, u6_u7, r25.discard, lsl 2, 0, 1, 1
 3e4: E7 00 54 2C 03 17 21 00 51 00 00 90 11 00  device_store     1, i32, x, r22, u6_u7, r23.discard, lsl 2, 0, 1, 1
 3f2: E7 00 54 06 03 05 21 00 51 00 00 90 11 00  device_store     1, i32, x, r3, u6_u7, r5.discard, lsl 2, 0, 1, 1
 400: 9F 01 54 0A 02 3A 08 8C 11 04              iadd             r5, 29, r1.cache
 40a: 9F 01 54 06 02 3C 08 8C 11 04              iadd             r3, 30, r1.cache
 414: 9F 01 54 02 02 3E 08 88 15 04              iadd             r1, 31, r1.discard
 41e: E7 00 55 28 03 15 21 00 51 00 00 90 11 00  device_store     1, i32, x, r20, u6_u7, r21.discard, lsl 2, 0, wait 4, 1, 1
 42c: E7 00 54 24 03 13 21 00 11 00 00 90 11 00  device_store     0, i32, x, r18, u6_u7, r19.discard, lsl 2, 0, 1, 1
 43a: E7 00 54 20 03 11 21 00 11 00 00 90 11 00  device_store     0, i32, x, r16, u6_u7, r17.discard, lsl 2, 0, 1, 1
 448: E7 00 54 1C 03 0F 21 00 11 00 00 90 11 00  device_store     0, i32, x, r14, u6_u7, r15.discard, lsl 2, 0, 1, 1
 456: E7 00 54 18 03 0D 21 00 11 00 00 90 11 00  device_store     0, i32, x, r12, u6_u7, r13.discard, lsl 2, 0, 1, 1
 464: E7 00 54 14 03 0B 21 00 11 00 00 90 11 00  device_store     0, i32, x, r10, u6_u7, r11.discard, lsl 2, 0, 1, 1
 472: E7 80 54 10 03 09 21 00 11 00 00 90 11 00  device_store     0, i32, x, r8, u6_u7, r9.discard, lsl 2, 0, wait 3, 1, 1
 480: E7 00 54 0C 03 07 21 00 11 00 00 90 11 00  device_store     0, i32, x, r6, u6_u7, r7.discard, lsl 2, 0, 1, 1
 48e: E7 00 54 08 03 05 21 00 11 00 00 90 11 00  device_store     0, i32, x, r4, u6_u7, r5.discard, lsl 2, 0, 1, 1
 49c: E7 00 54 04 03 03 21 00 11 00 00 90 11 00  device_store     0, i32, x, r2, u6_u7, r3.discard, lsl 2, 0, 1, 1
 4aa: E7 00 56 00 03 01 21 00 11 00 00 90 11 00  device_store     0, i32, x, r0, u6_u7, r1.discard, lsl 2, 0, wait 5, 1, 1
 4b8: 0E 00 00 00                                stop             
