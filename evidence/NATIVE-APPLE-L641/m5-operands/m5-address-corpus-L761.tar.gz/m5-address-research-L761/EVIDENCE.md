# L761 G17 direct/computed/gather address discriminator

## Scope and provenance

Compile-only experiment under private Mac lab `lab/m5-address-research-L761/`; Spark runtime binaries are private under `~/handoffs/native-apple-L641/L761-address` (mode 0700). Parent-owned research source stayed frozen at `da94831331abd3c66d05541fc53017ce4ed30371`; no interpreter/backend, shared branch, ledger, or PR changes. Nothing was dispatched to a GPU.

The first-party producer and all new golden/refusal assertions are `.om`. The existing Omega extractors were fingerprinted: `macho-extract.new` SHA256 `3d9517748894930810b15e3588db49cc11fe126c95fe776c6dbb742a0f5c7ce1`, `macho-inner.new` SHA256 `d58661b58cbfcd9eba0f03f2bdf39e7f19337ea31eece4d5c2b84dd5558109dd`. The external Apple compile-only oracle is Metal `32023.830` (binary SHA256 `c00b50f2e214242a093ca4c648f87e286e00dbee9edb5b2e395df17b62f73968`), `air-tt` SHA256 `4275b9c4d24010355d14a59419469eeb9551818384dc5ba059a0c2aed4113665`, `air-objdump` SHA256 `b3729c267bd669975d0457e9f0febd9b10ab17a0e7b2ea9a6770b801815b18e7`, pipeline JSON `k.mtlp-json` SHA256 `5a7695acdc1fdf69a1f58c48a6fa27b806b591a56bd1ab983cf5c4d37d4713c1`.

## Corpus contract and execution

Selector mapping is `family=selector/4`, `pressure=selector%4`; sources 0..15 were emitted and compiled:

| Family | Selector block | Address expression |
|---|---:|---|
| 0 | 0..3 | `gid` |
| 1 | 4..7 | `gid+5` |
| 2 | 8..11 | `j` |
| 3 | 12..15 | `j+5` |

Every generated kernel uses the same volatile `a,b,c` inputs and output order; it loads `j=b[gid]`, retains `pressure` values from `c[gid+i]`, forms `addr`, loads `v=a[addr]`, then stores `v`, `addr`, `j`, and retained values in that order. The visible MSL cases are `corpus/s00.metal`…`s15.metal`.

Seeded-compiled Omega gates executed:

- RED: the exact selector-0 golden rejected the existing incompatible index producer (test exit 1; old output 469 bytes).
- GREEN: exact goldens passed selectors 0, 4, 8, 12, and 15; these cover each family plus maximum retained pressure (selector 15, three retained values).
- Refusals: empty input, two-byte extra-input case, selector 16, and selector 255 each returned 65 with zero stdout; the compiled Omega refusal gate passed all four framed observations. The first pre-fix extra-byte attempt was retained: it incorrectly returned 0 and emitted 359 bytes; adding an explicit EOF read fixed the producer, and the rerun passed.
- All 16 valid selector outputs were generated; 16 Apple Metal frontend compilations and 32 architecture compilations succeeded.

Compile commands used the existing recipe settings: `metal -std=metal3.1 -target air64-apple-macosx26.0`, then `air-tt -arch applegpu_g16g|applegpu_g17g -platform_version macos 26.0 26.0 -o <stem>.gpubin k.mtlp-json <selector>.metallib`. The existing Omega extractors produced `.text` and `.macho`; `air-objdump --macho --syms` recorded symbols. Captures, per-step compiler logs, symbol reports, G16 decodes, and hashes are preserved under `corpus/`.

Membership verified against the 16 final selector sources. Counts: 16 `.metal`, 16 `.metallib`, 32 `.gpubin`, 32 `.text`, 32 `.macho`, 32 symbol reports, 16 G16 disassemblies, 96 logs. Every symbol report has exactly the `_agc.main` token at text offset `0x40` and separately `_agc.main.constant_program` at offset 0; exact-token counts are 32 each. `corpus/SHA256SUMS` covers 273 output files and passes `shasum -c`.

## Bounded byte/dataflow evidence

All offsets below are from extracted `.text`; symbol `_agc.main` starts at `0x40`. G16 decoding used only the existing independent disassembler with the symbol prefix skipped. G17 is **not** decoded here; byte sequence labels are candidate source-correlated spans, not a new G17 ISA decoder.

| Pair / controlled change | G17 `.text` bytes | G16 `.text` bytes | Observed bytes/dataflow |
|---|---:|---:|---|
| selector 0 vs 8, pressure 0; `addr=gid` vs `addr=j` | 144 vs 144 | 162 vs 162 | Candidate second-address/load span: G17 `s00` at `0x4c`: `4f 00 03 06 18 02 10 c0 41 00 80 00 00 00`; `s08`: `3f 00 03 02 18 02 10 c0 41 20 80 00 00 00`. The load-like `18 02 10 c0 41 xx 80` bytes keep `+1=02`; its `+5` byte at `0x55` changes `00`→`20`, while the immediately preceding four-byte span changes `4f 00 03 06`→`3f 00 03 02`. G16 independently shows the first load is `b[gid]` and the next load index changes from `gid` (s00) to the previously loaded `j` (s08). |
| selector 0 vs 4, pressure 0; `gid` vs `gid+5` | 144 vs 156 | 162 vs 172 | G17 s04 adds a 12-byte span at `0x44`: `27 05 04 3a 25 00 a3 0a a0 82 01 00`; whole-text length grows 12 bytes, so this is not a one-byte minimal pair. G16 decodes the corresponding `iadd ...,5,...` and the following `a` load using its result. |
| selector 8 vs 12, pressure 0; `j` vs `j+5` | 144 vs 156 | 162 vs 172 | G17 s12 has a 12-byte span at `0x4c`: `2f 01 04 3a 25 00 a3 0a 20 80 01 00`; whole-text length grows 12 bytes. G16 decodes `iadd r2,5,r0` before the `a` load, whose index is `r2`. |
| selector 12 vs 15, family 3; pressure 0 vs 3 | 156 vs 240 | 172 vs 286 | Three retained loads and their output stores change instruction ordering/register bytes and add 84 G17 bytes / 114 G16 bytes. The decoded G16 pressure-3 case has separate `b`, three `c`, and `a` loads; each retained value is stored. |

G17 text byte counts by pressure `p0,p1,p2,p3`:

| Family | Selector sequence | G17 bytes | G16 bytes |
|---|---|---|---|
| `gid` | 0..3 | 144, 172, 200, 228 | 162, 200, 238, 276 |
| `gid+5` | 4..7 | 156, 184, 212, 228 | 172, 210, 248, 276 |
| `j` | 8..11 | 144, 172, 200, 228 | 162, 200, 238, 276 |
| `j+5` | 12..15 | 156, 184, 212, 240 | 172, 210, 248, 286 |

The family-1 pressure-3 output is a useful non-additive case: its total size equals family-0 pressure-3 (228 bytes), unlike the +12 bytes at pressure 0..2. Since the retained c-store includes `out[gid+5]`, an address/store expression reuse is plausible, but the G17 bytes do not prove that explanation. G16's actual disassembly differs in register/dataflow details and is not a substitute for G17 decoding.

The raw G17 `+5` cases include a separate `27`/`2f`-leading 12-byte span; this is consistent with the cited upstream EXP-M5-11 report that constant offsets are lowered before the load, not carried as a load immediate. That report is third-party evidence. Its stronger claim that computed-index load byte `+5` is the index GPR was not independently proven by this compile-only capture: the local pair changes that byte `00`→`20` at candidate load offset `0x50`, but the preceding address span and register allocation change too. In particular, this source intentionally materializes `addr` (`a[addr]`) even for the `gid` family, so it does **not** reproduce the reference's literal `a[gid]` direct-mode control or its exact `amode 0x22`/`0x02` pair. Do not transplant the upstream field map from these correlations.

## Remaining boundary

This demonstrates actual paired G16/G17 compiler output for the requested source matrix and narrows the byte candidates. It does not establish G17 instruction boundaries/fields, physical register identity, dependency scheduling, caches, memory behavior, or hardware execution. All kernels are deliberately unsafe at runtime (dynamic `j` may be out of bounds; stores overlap lanes); GPU launch is prohibited and was not attempted. Parent performs final verification/publication.
