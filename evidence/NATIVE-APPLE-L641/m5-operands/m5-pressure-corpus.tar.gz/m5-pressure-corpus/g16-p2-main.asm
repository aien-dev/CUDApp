   0: BC A0 10 06                                get_sr           0, r11, sr32 (thread_position_in_grid.x)
   4: 67 10 54 10 00 0B 20 00 51 01 00 40 46 00  device_load      5, i32, x, r8, u0_u1, r11, lsl 2, 0, wait 0, 1, 1, 0
  12: 67 00 54 0C 01 0B 20 00 51 01 00 40 46 00  device_load      5, i32, x, r6, u2_u3, r11, lsl 2, 0, 1, 1, 0
  20: 9F 01 54 12 02 02 58 8C 11 04              iadd             r9, 1, r11.cache
  2a: 9F 01 54 0E 02 04 58 88 11 04              iadd             r7, 2, r11
  34: 67 00 54 08 02 0B 20 00 51 01 00 40 46 00  device_load      5, i32, x, r4, u4_u5, r11, lsl 2, 0, 1, 1, 0
  42: 67 00 54 04 00 09 20 00 11 00 00 40 46 00  device_load      0, i32, x, r2, u0_u1, r9, lsl 2, 0, 1, 1, 0
  50: 67 00 44 00 00 07 20 00 51 00 00 40 46 00  device_load      1, i32, x, r0, u0_u1, r7, lsl 2, 0, 1, 0, 0
  5e: 9F 00 56 14 02 18 40 40 D0 21 2A 00        imadd            r10, r6, r8, r4, wait 5
  6a: 9F 01 54 0A 02 06 58 8C 11 04              iadd             r5, 3, r11.cache
  74: 9F 01 54 06 02 08 58 8C 11 04              iadd             r3, 4, r11.cache
  7e: 9F 01 54 02 02 0A 58 88 11 04              iadd             r1, 5, r11
  88: E7 00 54 14 03 0B 21 00 11 00 00 90 11 00  device_store     0, i32, x, r10, u6_u7, r11.discard, lsl 2, 0, 1, 1
  96: E7 00 54 10 03 09 21 00 11 00 00 90 11 00  device_store     0, i32, x, r8, u6_u7, r9.discard, lsl 2, 0, 1, 1
  a4: E7 00 54 0C 03 07 21 00 11 00 00 90 11 00  device_store     0, i32, x, r6, u6_u7, r7.discard, lsl 2, 0, 1, 1
  b2: E7 00 54 08 03 05 21 00 11 00 00 90 11 00  device_store     0, i32, x, r4, u6_u7, r5.discard, lsl 2, 0, 1, 1
  c0: E7 10 54 04 03 03 21 00 11 00 00 90 11 00  device_store     0, i32, x, r2, u6_u7, r3.discard, lsl 2, 0, wait 0, 1, 1
  ce: E7 20 54 00 03 01 21 00 11 00 00 90 11 00  device_store     0, i32, x, r0, u6_u7, r1.discard, lsl 2, 0, wait 1, 1, 1
  dc: 0E 00 00 00                                stop             
