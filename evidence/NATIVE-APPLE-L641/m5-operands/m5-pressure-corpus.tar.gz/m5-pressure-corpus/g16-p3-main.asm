   0: DC A0 10 06                                get_sr           0, r13, sr32 (thread_position_in_grid.x)
   4: 67 10 54 14 00 0D 20 00 51 01 00 40 46 00  device_load      5, i32, x, r10, u0_u1, r13, lsl 2, 0, wait 0, 1, 1, 0
  12: 67 00 54 10 01 0D 20 00 51 01 00 40 46 00  device_load      5, i32, x, r8, u2_u3, r13, lsl 2, 0, 1, 1, 0
  20: 67 00 54 0C 02 0D 20 00 51 01 00 40 46 00  device_load      5, i32, x, r6, u4_u5, r13, lsl 2, 0, 1, 1, 0
  2e: 9F 01 54 16 02 02 68 8C 11 04              iadd             r11, 1, r13.cache
  38: 9F 01 54 12 02 04 68 8C 11 04              iadd             r9, 2, r13.cache
  42: 9F 01 54 0E 02 06 68 88 11 04              iadd             r7, 3, r13
  4c: 67 00 54 08 00 0B 20 00 11 00 00 40 46 00  device_load      0, i32, x, r4, u0_u1, r11, lsl 2, 0, 1, 1, 0
  5a: 67 00 54 04 00 09 20 00 51 00 00 40 46 00  device_load      1, i32, x, r2, u0_u1, r9, lsl 2, 0, 1, 1, 0
  68: 67 00 44 00 00 07 20 00 91 00 00 40 46 00  device_load      2, i32, x, r0, u0_u1, r7, lsl 2, 0, 1, 0, 0
  76: 9F 00 56 18 02 20 50 60 D0 21 2A 00        imadd            r12, r8, r10, r6, wait 5
  82: 9F 01 54 0A 02 08 68 8C 11 04              iadd             r5, 4, r13.cache
  8c: 9F 01 54 06 02 0A 68 8C 11 04              iadd             r3, 5, r13.cache
  96: 9F 01 54 02 02 0C 68 88 11 04              iadd             r1, 6, r13
  a0: E7 00 54 18 03 0D 21 00 11 00 00 90 11 00  device_store     0, i32, x, r12, u6_u7, r13.discard, lsl 2, 0, 1, 1
  ae: E7 00 54 14 03 0B 21 00 11 00 00 90 11 00  device_store     0, i32, x, r10, u6_u7, r11.discard, lsl 2, 0, 1, 1
  bc: E7 00 54 10 03 09 21 00 11 00 00 90 11 00  device_store     0, i32, x, r8, u6_u7, r9.discard, lsl 2, 0, 1, 1
  ca: E7 00 54 0C 03 07 21 00 11 00 00 90 11 00  device_store     0, i32, x, r6, u6_u7, r7.discard, lsl 2, 0, 1, 1
  d8: E7 10 54 08 03 05 21 00 11 00 00 90 11 00  device_store     0, i32, x, r4, u6_u7, r5.discard, lsl 2, 0, wait 0, 1, 1
  e6: E7 20 54 04 03 03 21 00 11 00 00 90 11 00  device_store     0, i32, x, r2, u6_u7, r3.discard, lsl 2, 0, wait 1, 1, 1
  f4: E7 40 54 00 03 01 21 00 11 00 00 90 11 00  device_store     0, i32, x, r0, u6_u7, r1.discard, lsl 2, 0, wait 2, 1, 1
 102: 0E 00 00 00                                stop             
