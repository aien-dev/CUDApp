   0: 1C A0 10 06                                get_sr           0, r1, sr32 (thread_position_in_grid.x)
   4: 9F 11 54 62 02 02 08 88 11 04              iadd             r49, 1, r1, wait 0
   e: 67 00 54 60 00 01 20 00 11 00 00 40 46 00  device_load      0, i32, x, r48, u0_u1, r1, lsl 2, 0, 1, 1, 0
  1c: 67 00 54 5C 01 01 20 00 11 00 00 40 46 00  device_load      0, i32, x, r46, u2_u3, r1, lsl 2, 0, 1, 1, 0
  2a: 67 00 54 58 02 01 20 00 11 00 00 40 46 00  device_load      0, i32, x, r44, u4_u5, r1, lsl 2, 0, 1, 1, 0
  38: 67 00 44 54 00 31 20 00 51 00 00 40 46 00  device_load      1, i32, x, r42, u0_u1, r49, lsl 2, 0, 1, 0, 0
  46: 9F 01 54 5E 02 04 08 8C 11 04              iadd             r47, 2, r1.cache
  50: 9F 01 54 5A 02 06 08 8C 11 04              iadd             r45, 3, r1.cache
  5a: 9F 01 54 56 02 08 08 8C 11 04              iadd             r43, 4, r1.cache
  64: 9F 01 54 52 02 0A 08 8C 11 04              iadd             r41, 5, r1.cache
  6e: 9F 01 54 4E 02 0C 08 8C 11 04              iadd             r39, 6, r1.cache
  78: 9F 01 54 4A 02 0E 08 8C 11 04              iadd             r37, 7, r1.cache
  82: 9F 01 64 46 02 10 08 8C 11 04              iadd.q2.todo     r35, 8, r1.cache
  8c: 9F 01 54 42 02 12 08 8C 11 04              iadd             r33, 9, r1.cache
  96: 9F 01 54 3E 02 14 08 8C 11 04              iadd             r31, 10, r1.cache
  a0: 9F 01 54 3A 02 16 08 8C 11 04              iadd             r29, 11, r1.cache
  aa: 9F 01 54 36 02 18 08 8C 11 04              iadd             r27, 12, r1.cache
  b4: 67 00 54 50 00 2F 20 00 51 00 00 40 46 00  device_load      1, i32, x, r40, u0_u1, r47, lsl 2, 0, 1, 1, 0
  c2: 67 00 54 4C 00 2D 20 00 51 00 00 40 46 00  device_load      1, i32, x, r38, u0_u1, r45, lsl 2, 0, 1, 1, 0
  d0: 67 00 54 48 00 2B 20 00 51 00 00 40 46 00  device_load      1, i32, x, r36, u0_u1, r43, lsl 2, 0, 1, 1, 0
  de: 67 00 54 44 00 29 20 00 51 00 00 40 46 00  device_load      1, i32, x, r34, u0_u1, r41, lsl 2, 0, 1, 1, 0
  ec: 67 00 54 40 00 27 20 00 51 01 00 40 46 00  device_load      5, i32, x, r32, u0_u1, r39, lsl 2, 0, 1, 1, 0
  fa: 67 00 54 3C 00 25 20 00 51 01 00 40 46 00  device_load      5, i32, x, r30, u0_u1, r37, lsl 2, 0, 1, 1, 0
 108: 67 00 54 38 00 23 20 00 51 01 00 40 46 00  device_load      5, i32, x, r28, u0_u1, r35, lsl 2, 0, 1, 1, 0
 116: 67 00 54 34 00 21 20 00 51 01 00 40 46 00  device_load      5, i32, x, r26, u0_u1, r33, lsl 2, 0, 1, 1, 0
 124: 67 00 54 30 00 1F 20 00 51 01 00 40 46 00  device_load      5, i32, x, r24, u0_u1, r31, lsl 2, 0, 1, 1, 0
 132: 67 00 54 2C 00 1D 20 00 51 01 00 40 46 00  device_load      5, i32, x, r22, u0_u1, r29, lsl 2, 0, 1, 1, 0
 140: 67 00 44 06 00 1B 20 00 51 01 00 40 46 00  device_load      5, i32, x, r3, u0_u1, r27, lsl 2, 0, 1, 0, 0
 14e: 9F 01 54 32 02 1A 08 8C 11 04              iadd             r25, 13, r1.cache
 158: 9F 01 54 2E 02 1C 08 8C 11 04              iadd             r23, 14, r1.cache
 162: 9F 01 54 0A 02 1E 08 8C 11 04              iadd             r5, 15, r1.cache
 16c: 9F 01 54 2A 02 20 08 8C 11 04              iadd             r21, 16, r1.cache
 176: 9F 01 54 26 02 22 08 8C 11 04              iadd             r19, 17, r1.cache
 180: 9F 01 54 22 02 24 08 8C 11 04              iadd             r17, 18, r1.cache
 18a: 9F 01 64 1E 02 26 08 8C 11 04              iadd.q2.todo     r15, 19, r1.cache
 194: 9F 01 54 1A 02 28 08 8C 11 04              iadd             r13, 20, r1.cache
 19e: 9F 01 54 16 02 2A 08 8C 11 04              iadd             r11, 21, r1.cache
 1a8: 9F 01 54 12 02 2C 08 8C 11 04              iadd             r9, 22, r1.cache
 1b2: 9F 01 54 0E 02 2E 08 88 11 04              iadd             r7, 23, r1
 1bc: 67 00 54 28 00 19 20 00 91 00 00 40 46 00  device_load      2, i32, x, r20, u0_u1, r25, lsl 2, 0, 1, 1, 0
 1ca: 67 00 54 24 00 17 20 00 91 00 00 40 46 00  device_load      2, i32, x, r18, u0_u1, r23, lsl 2, 0, 1, 1, 0
 1d8: 67 00 54 20 00 05 20 00 91 00 00 40 46 00  device_load      2, i32, x, r16, u0_u1, r5, lsl 2, 0, 1, 1, 0
 1e6: 67 00 54 1C 00 15 20 00 91 00 00 40 46 00  device_load      2, i32, x, r14, u0_u1, r21, lsl 2, 0, 1, 1, 0
 1f4: 67 00 54 18 00 13 20 00 91 00 00 40 46 00  device_load      2, i32, x, r12, u0_u1, r19, lsl 2, 0, 1, 1, 0
 202: 67 00 54 14 00 11 20 00 91 00 00 40 46 00  device_load      2, i32, x, r10, u0_u1, r17, lsl 2, 0, 1, 1, 0
 210: 67 00 54 10 00 0F 20 00 91 00 00 40 46 00  device_load      2, i32, x, r8, u0_u1, r15, lsl 2, 0, 1, 1, 0
 21e: 67 00 54 0C 00 0D 20 00 11 01 00 40 46 00  device_load      4, i32, x, r6, u0_u1, r13, lsl 2, 0, 1, 1, 0
 22c: 67 00 54 08 00 0B 20 00 11 01 00 40 46 00  device_load      4, i32, x, r4, u0_u1, r11, lsl 2, 0, 1, 1, 0
 23a: 67 00 54 04 00 09 20 00 11 01 00 40 46 00  device_load      4, i32, x, r2, u0_u1, r9, lsl 2, 0, 1, 1, 0
 248: 67 00 44 00 00 07 20 00 D1 00 00 40 46 00  device_load      3, i32, x, r0, u0_u1, r7, lsl 2, 0, 1, 0, 0
 256: 9F 10 54 64 02 B8 80 C1 D2 21 2A 00        imadd            r50, r46, r48, r44, wait 0
 262: E7 00 54 64 03 01 20 00 51 00 00 90 11 00  device_store     1, i32, x, r50, u6_u7, r1, lsl 2, 0, 1, 1
 270: E7 00 54 60 03 31 21 00 51 00 00 90 11 00  device_store     1, i32, x, r48, u6_u7, r49.discard, lsl 2, 0, 1, 1
 27e: E7 00 54 5C 03 2F 21 00 51 00 00 90 11 00  device_store     1, i32, x, r46, u6_u7, r47.discard, lsl 2, 0, 1, 1
 28c: E7 00 54 58 03 2D 21 00 51 00 00 90 11 00  device_store     1, i32, x, r44, u6_u7, r45.discard, lsl 2, 0, 1, 1
 29a: E7 20 54 54 03 2B 21 00 51 00 00 90 11 00  device_store     1, i32, x, r42, u6_u7, r43.discard, lsl 2, 0, wait 1, 1, 1
 2a8: E7 00 54 50 03 29 21 00 51 00 00 90 11 00  device_store     1, i32, x, r40, u6_u7, r41.discard, lsl 2, 0, 1, 1
 2b6: E7 00 54 4C 03 27 21 00 51 00 00 90 11 00  device_store     1, i32, x, r38, u6_u7, r39.discard, lsl 2, 0, 1, 1
 2c4: E7 00 54 48 03 25 21 00 51 00 00 90 11 00  device_store     1, i32, x, r36, u6_u7, r37.discard, lsl 2, 0, 1, 1
 2d2: E7 00 54 44 03 23 21 00 51 00 00 90 11 00  device_store     1, i32, x, r34, u6_u7, r35.discard, lsl 2, 0, 1, 1
 2e0: E7 00 56 40 03 21 21 00 51 00 00 90 11 00  device_store     1, i32, x, r32, u6_u7, r33.discard, lsl 2, 0, wait 5, 1, 1
 2ee: E7 00 54 3C 03 1F 21 00 51 00 00 90 11 00  device_store     1, i32, x, r30, u6_u7, r31.discard, lsl 2, 0, 1, 1
 2fc: E7 00 54 38 03 1D 21 00 51 00 00 90 11 00  device_store     1, i32, x, r28, u6_u7, r29.discard, lsl 2, 0, 1, 1
 30a: E7 00 54 34 03 1B 21 00 51 00 00 90 11 00  device_store     1, i32, x, r26, u6_u7, r27.discard, lsl 2, 0, 1, 1
 318: E7 00 54 30 03 19 21 00 51 00 00 90 11 00  device_store     1, i32, x, r24, u6_u7, r25.discard, lsl 2, 0, 1, 1
 326: E7 00 54 2C 03 17 21 00 51 00 00 90 11 00  device_store     1, i32, x, r22, u6_u7, r23.discard, lsl 2, 0, 1, 1
 334: E7 00 54 06 03 05 21 00 51 00 00 90 11 00  device_store     1, i32, x, r3, u6_u7, r5.discard, lsl 2, 0, 1, 1
 342: 9F 01 54 0A 02 30 08 8C 11 04              iadd             r5, 24, r1.cache
 34c: 9F 01 54 06 02 32 08 8C 11 04              iadd             r3, 25, r1.cache
 356: 9F 01 54 02 02 34 08 88 15 04              iadd             r1, 26, r1.discard
 360: E7 40 54 28 03 15 21 00 51 00 00 90 11 00  device_store     1, i32, x, r20, u6_u7, r21.discard, lsl 2, 0, wait 2, 1, 1
 36e: E7 00 54 24 03 13 21 00 11 00 00 90 11 00  device_store     0, i32, x, r18, u6_u7, r19.discard, lsl 2, 0, 1, 1
 37c: E7 00 54 20 03 11 21 00 11 00 00 90 11 00  device_store     0, i32, x, r16, u6_u7, r17.discard, lsl 2, 0, 1, 1
 38a: E7 00 54 1C 03 0F 21 00 11 00 00 90 11 00  device_store     0, i32, x, r14, u6_u7, r15.discard, lsl 2, 0, 1, 1
 398: E7 00 54 18 03 0D 21 00 11 00 00 90 11 00  device_store     0, i32, x, r12, u6_u7, r13.discard, lsl 2, 0, 1, 1
 3a6: E7 00 54 14 03 0B 21 00 11 00 00 90 11 00  device_store     0, i32, x, r10, u6_u7, r11.discard, lsl 2, 0, 1, 1
 3b4: E7 00 54 10 03 09 21 00 11 00 00 90 11 00  device_store     0, i32, x, r8, u6_u7, r9.discard, lsl 2, 0, 1, 1
 3c2: E7 00 55 0C 03 07 21 00 11 00 00 90 11 00  device_store     0, i32, x, r6, u6_u7, r7.discard, lsl 2, 0, wait 4, 1, 1
 3d0: E7 00 54 08 03 05 21 00 11 00 00 90 11 00  device_store     0, i32, x, r4, u6_u7, r5.discard, lsl 2, 0, 1, 1
 3de: E7 00 54 04 03 03 21 00 11 00 00 90 11 00  device_store     0, i32, x, r2, u6_u7, r3.discard, lsl 2, 0, 1, 1
 3ec: E7 80 54 00 03 01 21 00 11 00 00 90 11 00  device_store     0, i32, x, r0, u6_u7, r1.discard, lsl 2, 0, wait 3, 1, 1
 3fa: 0E 00 00 00                                stop             
