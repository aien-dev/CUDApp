   0: 03 00 07 00 02 00 00 00 60 00              mov.todo         r0l, r0l
   a: 0E 00 00 00                                stop             
