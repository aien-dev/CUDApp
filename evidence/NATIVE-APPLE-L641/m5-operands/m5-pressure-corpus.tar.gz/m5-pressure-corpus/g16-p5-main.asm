   0: 1C A0 50 06                                get_sr           0, r17, sr32 (thread_position_in_grid.x)
   4: 67 10 54 1C 00 11 20 00 51 01 00 40 46 00  device_load      5, i32, x, r14, u0_u1, r17, lsl 2, 0, wait 0, 1, 1, 0
  12: 67 00 54 18 01 11 20 00 51 01 00 40 46 00  device_load      5, i32, x, r12, u2_u3, r17, lsl 2, 0, 1, 1, 0
  20: 67 00 54 14 02 11 20 00 51 01 00 40 46 00  device_load      5, i32, x, r10, u4_u5, r17, lsl 2, 0, 1, 1, 0
  2e: 9F 01 54 1E 02 02 88 8C 11 04              iadd             r15, 1, r17.cache
  38: 9F 01 54 1A 02 04 88 8C 11 04              iadd             r13, 2, r17.cache
  42: 9F 01 54 16 02 06 88 8C 11 04              iadd             r11, 3, r17.cache
  4c: 9F 01 54 12 02 08 88 8C 11 04              iadd             r9, 4, r17.cache
  56: 9F 01 54 0E 02 0A 88 88 11 04              iadd             r7, 5, r17
  60: 67 00 54 10 00 0F 20 00 11 00 00 40 46 00  device_load      0, i32, x, r8, u0_u1, r15, lsl 2, 0, 1, 1, 0
  6e: 67 00 54 0C 00 0D 20 00 51 00 00 40 46 00  device_load      1, i32, x, r6, u0_u1, r13, lsl 2, 0, 1, 1, 0
  7c: 67 00 54 08 00 0B 20 00 91 00 00 40 46 00  device_load      2, i32, x, r4, u0_u1, r11, lsl 2, 0, 1, 1, 0
  8a: 67 00 54 04 00 09 20 00 D1 00 00 40 46 00  device_load      3, i32, x, r2, u0_u1, r9, lsl 2, 0, 1, 1, 0
  98: 67 00 44 00 00 07 20 00 11 01 00 40 46 00  device_load      4, i32, x, r0, u0_u1, r7, lsl 2, 0, 1, 0, 0
  a6: 9F 00 56 20 02 30 70 A0 D0 21 2A 00        imadd            r16, r12, r14, r10, wait 5
  b2: 9F 01 54 0A 02 0C 88 8C 11 04              iadd             r5, 6, r17.cache
  bc: 9F 01 54 06 02 0E 88 8C 11 04              iadd             r3, 7, r17.cache
  c6: 9F 01 54 02 02 10 88 88 11 04              iadd             r1, 8, r17
  d0: E7 00 54 20 03 11 21 00 11 00 00 90 11 00  device_store     0, i32, x, r16, u6_u7, r17.discard, lsl 2, 0, 1, 1
  de: E7 00 54 1C 03 0F 21 00 11 00 00 90 11 00  device_store     0, i32, x, r14, u6_u7, r15.discard, lsl 2, 0, 1, 1
  ec: E7 00 54 18 03 0D 21 00 11 00 00 90 11 00  device_store     0, i32, x, r12, u6_u7, r13.discard, lsl 2, 0, 1, 1
  fa: E7 00 54 14 03 0B 21 00 11 00 00 90 11 00  device_store     0, i32, x, r10, u6_u7, r11.discard, lsl 2, 0, 1, 1
 108: E7 10 54 10 03 09 21 00 11 00 00 90 11 00  device_store     0, i32, x, r8, u6_u7, r9.discard, lsl 2, 0, wait 0, 1, 1
 116: E7 20 54 0C 03 07 21 00 11 00 00 90 11 00  device_store     0, i32, x, r6, u6_u7, r7.discard, lsl 2, 0, wait 1, 1, 1
 124: E7 40 54 08 03 05 21 00 11 00 00 90 11 00  device_store     0, i32, x, r4, u6_u7, r5.discard, lsl 2, 0, wait 2, 1, 1
 132: E7 80 54 04 03 03 21 00 11 00 00 90 11 00  device_store     0, i32, x, r2, u6_u7, r3.discard, lsl 2, 0, wait 3, 1, 1
 140: E7 00 55 00 03 01 21 00 11 00 00 90 11 00  device_store     0, i32, x, r0, u6_u7, r1.discard, lsl 2, 0, wait 4, 1, 1
 14e: 0E 00 00 00                                stop             
