   0: 1C A0 10 06                                get_sr           0, r1, sr32 (thread_position_in_grid.x)
   4: 9F 11 54 3A 02 02 08 8C 11 04              iadd             r29, 1, r1.cache, wait 0
   e: 9F 01 54 36 02 04 08 88 11 04              iadd             r27, 2, r1
  18: 67 00 54 38 00 01 20 00 51 01 00 40 46 00  device_load      5, i32, x, r28, u0_u1, r1, lsl 2, 0, 1, 1, 0
  26: 67 00 54 34 01 01 20 00 51 01 00 40 46 00  device_load      5, i32, x, r26, u2_u3, r1, lsl 2, 0, 1, 1, 0
  34: 67 00 54 30 02 01 20 00 51 01 00 40 46 00  device_load      5, i32, x, r24, u4_u5, r1, lsl 2, 0, 1, 1, 0
  42: 67 00 54 2C 00 1D 20 00 11 00 00 40 46 00  device_load      0, i32, x, r22, u0_u1, r29, lsl 2, 0, 1, 1, 0
  50: 67 00 44 06 00 1B 20 00 11 00 00 40 46 00  device_load      0, i32, x, r3, u0_u1, r27, lsl 2, 0, 1, 0, 0
  5e: 9F 01 54 32 02 06 08 8C 11 04              iadd             r25, 3, r1.cache
  68: 9F 01 54 2E 02 08 08 8C 11 04              iadd             r23, 4, r1.cache
  72: 9F 01 54 0A 02 0A 08 8C 11 04              iadd             r5, 5, r1.cache
  7c: 9F 01 54 2A 02 0C 08 8C 11 04              iadd             r21, 6, r1.cache
  86: 9F 01 54 26 02 0E 08 8C 11 04              iadd             r19, 7, r1.cache
  90: 9F 01 54 22 02 10 08 8C 11 04              iadd             r17, 8, r1.cache
  9a: 9F 01 64 1E 02 12 08 8C 11 04              iadd.q2.todo     r15, 9, r1.cache
  a4: 9F 01 54 1A 02 14 08 8C 11 04              iadd             r13, 10, r1.cache
  ae: 9F 01 54 16 02 16 08 8C 11 04              iadd             r11, 11, r1.cache
  b8: 9F 01 54 12 02 18 08 8C 11 04              iadd             r9, 12, r1.cache
  c2: 9F 01 54 0E 02 1A 08 88 11 04              iadd             r7, 13, r1
  cc: 67 00 54 28 00 19 20 00 91 00 00 40 46 00  device_load      2, i32, x, r20, u0_u1, r25, lsl 2, 0, 1, 1, 0
  da: 67 00 54 24 00 17 20 00 91 00 00 40 46 00  device_load      2, i32, x, r18, u0_u1, r23, lsl 2, 0, 1, 1, 0
  e8: 67 00 54 20 00 05 20 00 91 00 00 40 46 00  device_load      2, i32, x, r16, u0_u1, r5, lsl 2, 0, 1, 1, 0
  f6: 67 00 54 1C 00 15 20 00 11 01 00 40 46 00  device_load      4, i32, x, r14, u0_u1, r21, lsl 2, 0, 1, 1, 0
 104: 67 00 54 18 00 13 20 00 11 01 00 40 46 00  device_load      4, i32, x, r12, u0_u1, r19, lsl 2, 0, 1, 1, 0
 112: 67 00 54 14 00 11 20 00 11 01 00 40 46 00  device_load      4, i32, x, r10, u0_u1, r17, lsl 2, 0, 1, 1, 0
 120: 67 00 54 10 00 0F 20 00 11 01 00 40 46 00  device_load      4, i32, x, r8, u0_u1, r15, lsl 2, 0, 1, 1, 0
 12e: 67 00 54 0C 00 0D 20 00 11 01 00 40 46 00  device_load      4, i32, x, r6, u0_u1, r13, lsl 2, 0, 1, 1, 0
 13c: 67 00 54 08 00 0B 20 00 51 00 00 40 46 00  device_load      1, i32, x, r4, u0_u1, r11, lsl 2, 0, 1, 1, 0
 14a: 67 00 54 04 00 09 20 00 51 00 00 40 46 00  device_load      1, i32, x, r2, u0_u1, r9, lsl 2, 0, 1, 1, 0
 158: 67 00 44 00 00 07 20 00 D1 00 00 40 46 00  device_load      3, i32, x, r0, u0_u1, r7, lsl 2, 0, 1, 0, 0
 166: 9F 00 56 3C 02 68 E0 80 D1 21 2A 00        imadd            r30, r26, r28, r24, wait 5
 172: E7 00 54 3C 03 01 20 00 51 00 00 90 11 00  device_store     1, i32, x, r30, u6_u7, r1, lsl 2, 0, 1, 1
 180: E7 00 54 38 03 1D 21 00 51 00 00 90 11 00  device_store     1, i32, x, r28, u6_u7, r29.discard, lsl 2, 0, 1, 1
 18e: E7 00 54 34 03 1B 21 00 51 00 00 90 11 00  device_store     1, i32, x, r26, u6_u7, r27.discard, lsl 2, 0, 1, 1
 19c: E7 00 54 30 03 19 21 00 51 00 00 90 11 00  device_store     1, i32, x, r24, u6_u7, r25.discard, lsl 2, 0, 1, 1
 1aa: E7 10 54 2C 03 17 21 00 51 00 00 90 11 00  device_store     1, i32, x, r22, u6_u7, r23.discard, lsl 2, 0, wait 0, 1, 1
 1b8: E7 00 54 06 03 05 21 00 51 00 00 90 11 00  device_store     1, i32, x, r3, u6_u7, r5.discard, lsl 2, 0, 1, 1
 1c6: 9F 01 54 0A 02 1C 08 8C 11 04              iadd             r5, 14, r1.cache
 1d0: 9F 01 54 06 02 1E 08 8C 11 04              iadd             r3, 15, r1.cache
 1da: 9F 01 54 02 02 20 08 88 15 04              iadd             r1, 16, r1.discard
 1e4: E7 40 54 28 03 15 21 00 51 00 00 90 11 00  device_store     1, i32, x, r20, u6_u7, r21.discard, lsl 2, 0, wait 2, 1, 1
 1f2: E7 00 54 24 03 13 21 00 11 00 00 90 11 00  device_store     0, i32, x, r18, u6_u7, r19.discard, lsl 2, 0, 1, 1
 200: E7 00 54 20 03 11 21 00 11 00 00 90 11 00  device_store     0, i32, x, r16, u6_u7, r17.discard, lsl 2, 0, 1, 1
 20e: E7 00 55 1C 03 0F 21 00 11 00 00 90 11 00  device_store     0, i32, x, r14, u6_u7, r15.discard, lsl 2, 0, wait 4, 1, 1
 21c: E7 00 54 18 03 0D 21 00 11 00 00 90 11 00  device_store     0, i32, x, r12, u6_u7, r13.discard, lsl 2, 0, 1, 1
 22a: E7 00 54 14 03 0B 21 00 11 00 00 90 11 00  device_store     0, i32, x, r10, u6_u7, r11.discard, lsl 2, 0, 1, 1
 238: E7 00 54 10 03 09 21 00 11 00 00 90 11 00  device_store     0, i32, x, r8, u6_u7, r9.discard, lsl 2, 0, 1, 1
 246: E7 00 54 0C 03 07 21 00 11 00 00 90 11 00  device_store     0, i32, x, r6, u6_u7, r7.discard, lsl 2, 0, 1, 1
 254: E7 20 54 08 03 05 21 00 11 00 00 90 11 00  device_store     0, i32, x, r4, u6_u7, r5.discard, lsl 2, 0, wait 1, 1, 1
 262: E7 00 54 04 03 03 21 00 11 00 00 90 11 00  device_store     0, i32, x, r2, u6_u7, r3.discard, lsl 2, 0, 1, 1
 270: E7 80 54 00 03 01 21 00 11 00 00 90 11 00  device_store     0, i32, x, r0, u6_u7, r1.discard, lsl 2, 0, wait 3, 1, 1
 27e: 0E 00 00 00                                stop             
