#include <metal_stdlib>
using namespace metal;
kernel void k(volatile device const int *w [[buffer(0)]], volatile device const int *x [[buffer(1)]], device int *out [[buffer(2)]], uint gid [[thread_position_in_grid]]) {
uint base = gid * 2;
int s = 0;
s += w[base + 0] * x[0];
s += w[base + 1] * x[1];
out[gid] = s;
}
