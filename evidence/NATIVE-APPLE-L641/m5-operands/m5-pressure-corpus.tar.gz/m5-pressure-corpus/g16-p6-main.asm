   0: 3C A0 50 06                                get_sr           0, r19, sr32 (thread_position_in_grid.x)
   4: 67 10 54 20 00 13 20 00 51 01 00 40 46 00  device_load      5, i32, x, r16, u0_u1, r19, lsl 2, 0, wait 0, 1, 1, 0
  12: 67 00 54 1C 01 13 20 00 51 01 00 40 46 00  device_load      5, i32, x, r14, u2_u3, r19, lsl 2, 0, 1, 1, 0
  20: 67 00 54 18 02 13 20 00 51 01 00 40 46 00  device_load      5, i32, x, r12, u4_u5, r19, lsl 2, 0, 1, 1, 0
  2e: 9F 01 54 22 02 02 98 8C 11 04              iadd             r17, 1, r19.cache
  38: 9F 01 54 1E 02 04 98 8C 11 04              iadd             r15, 2, r19.cache
  42: 9F 01 54 1A 02 06 98 8C 11 04              iadd             r13, 3, r19.cache
  4c: 9F 01 54 16 02 08 98 8C 11 04              iadd             r11, 4, r19.cache
  56: 9F 01 54 12 02 0A 98 8C 11 04              iadd             r9, 5, r19.cache
  60: 9F 01 54 0E 02 0C 98 88 11 04              iadd             r7, 6, r19
  6a: 67 00 54 14 00 11 20 00 11 00 00 40 46 00  device_load      0, i32, x, r10, u0_u1, r17, lsl 2, 0, 1, 1, 0
  78: 67 00 54 10 00 0F 20 00 51 00 00 40 46 00  device_load      1, i32, x, r8, u0_u1, r15, lsl 2, 0, 1, 1, 0
  86: 67 00 54 0C 00 0D 20 00 91 00 00 40 46 00  device_load      2, i32, x, r6, u0_u1, r13, lsl 2, 0, 1, 1, 0
  94: 67 00 54 08 00 0B 20 00 D1 00 00 40 46 00  device_load      3, i32, x, r4, u0_u1, r11, lsl 2, 0, 1, 1, 0
  a2: 67 00 54 04 00 09 20 00 D1 00 00 40 46 00  device_load      3, i32, x, r2, u0_u1, r9, lsl 2, 0, 1, 1, 0
  b0: 67 00 44 00 00 07 20 00 11 01 00 40 46 00  device_load      4, i32, x, r0, u0_u1, r7, lsl 2, 0, 1, 0, 0
  be: 9F 00 56 24 02 38 80 C0 D0 21 2A 00        imadd            r18, r14, r16, r12, wait 5
  ca: 9F 01 54 0A 02 0E 98 8C 11 04              iadd             r5, 7, r19.cache
  d4: 9F 01 54 06 02 10 98 8C 11 04              iadd             r3, 8, r19.cache
  de: 9F 01 54 02 02 12 98 88 11 04              iadd             r1, 9, r19
  e8: E7 00 54 24 03 13 21 00 11 00 00 90 11 00  device_store     0, i32, x, r18, u6_u7, r19.discard, lsl 2, 0, 1, 1
  f6: E7 00 54 20 03 11 21 00 11 00 00 90 11 00  device_store     0, i32, x, r16, u6_u7, r17.discard, lsl 2, 0, 1, 1
 104: E7 00 54 1C 03 0F 21 00 11 00 00 90 11 00  device_store     0, i32, x, r14, u6_u7, r15.discard, lsl 2, 0, 1, 1
 112: E7 00 54 18 03 0D 21 00 11 00 00 90 11 00  device_store     0, i32, x, r12, u6_u7, r13.discard, lsl 2, 0, 1, 1
 120: E7 10 54 14 03 0B 21 00 11 00 00 90 11 00  device_store     0, i32, x, r10, u6_u7, r11.discard, lsl 2, 0, wait 0, 1, 1
 12e: E7 20 54 10 03 09 21 00 11 00 00 90 11 00  device_store     0, i32, x, r8, u6_u7, r9.discard, lsl 2, 0, wait 1, 1, 1
 13c: E7 40 54 0C 03 07 21 00 11 00 00 90 11 00  device_store     0, i32, x, r6, u6_u7, r7.discard, lsl 2, 0, wait 2, 1, 1
 14a: E7 80 54 08 03 05 21 00 11 00 00 90 11 00  device_store     0, i32, x, r4, u6_u7, r5.discard, lsl 2, 0, wait 3, 1, 1
 158: E7 00 54 04 03 03 21 00 11 00 00 90 11 00  device_store     0, i32, x, r2, u6_u7, r3.discard, lsl 2, 0, 1, 1
 166: E7 00 55 00 03 01 21 00 11 00 00 90 11 00  device_store     0, i32, x, r0, u6_u7, r1.discard, lsl 2, 0, wait 4, 1, 1
 174: 0E 00 00 00                                stop             
