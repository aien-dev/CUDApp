#include <metal_stdlib>
using namespace metal;
kernel void k(volatile device const uint *a [[buffer(0)]], volatile device const uint *b [[buffer(1)]], volatile device const uint *c [[buffer(2)]], device uint *out [[buffer(3)]], uint gid [[thread_position_in_grid]]) {
uint va=a[gid]; uint vb=b[gid]; uint vc=c[gid];
uint vi=a[gid+22]; uint offset=gid+22;
out[gid] = va * vb + vc;
out[gid+1] = va; out[gid+2] = vb; out[gid+3] = vc;
out[gid+4] = vi; out[gid+5] = offset;
}
