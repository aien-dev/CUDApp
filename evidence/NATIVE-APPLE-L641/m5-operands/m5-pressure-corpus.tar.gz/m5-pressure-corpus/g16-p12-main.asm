   0: 1C A0 10 06                                get_sr           0, r1, sr32 (thread_position_in_grid.x)
   4: 9F 11 54 36 02 02 08 88 11 04              iadd             r27, 1, r1, wait 0
   e: 67 00 54 34 00 01 20 00 51 01 00 40 46 00  device_load      5, i32, x, r26, u0_u1, r1, lsl 2, 0, 1, 1, 0
  1c: 67 00 54 30 01 01 20 00 51 01 00 40 46 00  device_load      5, i32, x, r24, u2_u3, r1, lsl 2, 0, 1, 1, 0
  2a: 67 00 54 2C 02 01 20 00 51 01 00 40 46 00  device_load      5, i32, x, r22, u4_u5, r1, lsl 2, 0, 1, 1, 0
  38: 67 00 44 06 00 1B 20 00 11 00 00 40 46 00  device_load      0, i32, x, r3, u0_u1, r27, lsl 2, 0, 1, 0, 0
  46: 9F 01 54 32 02 04 08 8C 11 04              iadd             r25, 2, r1.cache
  50: 9F 01 54 2E 02 06 08 8C 11 04              iadd             r23, 3, r1.cache
  5a: 9F 01 54 0A 02 08 08 8C 11 04              iadd             r5, 4, r1.cache
  64: 9F 01 54 2A 02 0A 08 8C 11 04              iadd             r21, 5, r1.cache
  6e: 9F 01 54 26 02 0C 08 8C 11 04              iadd             r19, 6, r1.cache
  78: 9F 01 54 22 02 0E 08 8C 11 04              iadd             r17, 7, r1.cache
  82: 9F 01 64 1E 02 10 08 8C 11 04              iadd.q2.todo     r15, 8, r1.cache
  8c: 9F 01 54 1A 02 12 08 8C 11 04              iadd             r13, 9, r1.cache
  96: 9F 01 54 16 02 14 08 8C 11 04              iadd             r11, 10, r1.cache
  a0: 9F 01 54 12 02 16 08 8C 11 04              iadd             r9, 11, r1.cache
  aa: 9F 01 54 0E 02 18 08 88 11 04              iadd             r7, 12, r1
  b4: 67 00 54 28 00 19 20 00 51 00 00 40 46 00  device_load      1, i32, x, r20, u0_u1, r25, lsl 2, 0, 1, 1, 0
  c2: 67 00 54 24 00 17 20 00 51 00 00 40 46 00  device_load      1, i32, x, r18, u0_u1, r23, lsl 2, 0, 1, 1, 0
  d0: 67 00 54 20 00 05 20 00 51 00 00 40 46 00  device_load      1, i32, x, r16, u0_u1, r5, lsl 2, 0, 1, 1, 0
  de: 67 00 54 1C 00 15 20 00 51 00 00 40 46 00  device_load      1, i32, x, r14, u0_u1, r21, lsl 2, 0, 1, 1, 0
  ec: 67 00 54 18 00 13 20 00 11 01 00 40 46 00  device_load      4, i32, x, r12, u0_u1, r19, lsl 2, 0, 1, 1, 0
  fa: 67 00 54 14 00 11 20 00 11 01 00 40 46 00  device_load      4, i32, x, r10, u0_u1, r17, lsl 2, 0, 1, 1, 0
 108: 67 00 54 10 00 0F 20 00 11 01 00 40 46 00  device_load      4, i32, x, r8, u0_u1, r15, lsl 2, 0, 1, 1, 0
 116: 67 00 54 0C 00 0D 20 00 11 01 00 40 46 00  device_load      4, i32, x, r6, u0_u1, r13, lsl 2, 0, 1, 1, 0
 124: 67 00 54 08 00 0B 20 00 11 01 00 40 46 00  device_load      4, i32, x, r4, u0_u1, r11, lsl 2, 0, 1, 1, 0
 132: 67 00 54 04 00 09 20 00 91 00 00 40 46 00  device_load      2, i32, x, r2, u0_u1, r9, lsl 2, 0, 1, 1, 0
 140: 67 00 44 00 00 07 20 00 D1 00 00 40 46 00  device_load      3, i32, x, r0, u0_u1, r7, lsl 2, 0, 1, 0, 0
 14e: 9F 00 56 3A 02 60 D0 60 D1 21 2A 00        imadd            r29, r24, r26, r22, wait 5
 15a: E7 00 54 3A 03 01 20 00 51 00 00 90 11 00  device_store     1, i32, x, r29, u6_u7, r1, lsl 2, 0, 1, 1
 168: E7 00 54 34 03 1B 21 00 51 00 00 90 11 00  device_store     1, i32, x, r26, u6_u7, r27.discard, lsl 2, 0, 1, 1
 176: E7 00 54 30 03 19 21 00 51 00 00 90 11 00  device_store     1, i32, x, r24, u6_u7, r25.discard, lsl 2, 0, 1, 1
 184: E7 00 54 2C 03 17 21 00 51 00 00 90 11 00  device_store     1, i32, x, r22, u6_u7, r23.discard, lsl 2, 0, 1, 1
 192: E7 10 54 06 03 05 21 00 51 00 00 90 11 00  device_store     1, i32, x, r3, u6_u7, r5.discard, lsl 2, 0, wait 0, 1, 1
 1a0: 9F 01 54 0A 02 1A 08 8C 11 04              iadd             r5, 13, r1.cache
 1aa: 9F 01 54 06 02 1C 08 8C 11 04              iadd             r3, 14, r1.cache
 1b4: 9F 01 54 02 02 1E 08 88 15 04              iadd             r1, 15, r1.discard
 1be: E7 20 54 28 03 15 21 00 51 00 00 90 11 00  device_store     1, i32, x, r20, u6_u7, r21.discard, lsl 2, 0, wait 1, 1, 1
 1cc: E7 00 54 24 03 13 21 00 11 00 00 90 11 00  device_store     0, i32, x, r18, u6_u7, r19.discard, lsl 2, 0, 1, 1
 1da: E7 00 54 20 03 11 21 00 11 00 00 90 11 00  device_store     0, i32, x, r16, u6_u7, r17.discard, lsl 2, 0, 1, 1
 1e8: E7 00 54 1C 03 0F 21 00 11 00 00 90 11 00  device_store     0, i32, x, r14, u6_u7, r15.discard, lsl 2, 0, 1, 1
 1f6: E7 00 55 18 03 0D 21 00 11 00 00 90 11 00  device_store     0, i32, x, r12, u6_u7, r13.discard, lsl 2, 0, wait 4, 1, 1
 204: E7 00 54 14 03 0B 21 00 11 00 00 90 11 00  device_store     0, i32, x, r10, u6_u7, r11.discard, lsl 2, 0, 1, 1
 212: E7 00 54 10 03 09 21 00 11 00 00 90 11 00  device_store     0, i32, x, r8, u6_u7, r9.discard, lsl 2, 0, 1, 1
 220: E7 00 54 0C 03 07 21 00 11 00 00 90 11 00  device_store     0, i32, x, r6, u6_u7, r7.discard, lsl 2, 0, 1, 1
 22e: E7 00 54 08 03 05 21 00 11 00 00 90 11 00  device_store     0, i32, x, r4, u6_u7, r5.discard, lsl 2, 0, 1, 1
 23c: E7 40 54 04 03 03 21 00 11 00 00 90 11 00  device_store     0, i32, x, r2, u6_u7, r3.discard, lsl 2, 0, wait 2, 1, 1
 24a: E7 80 54 00 03 01 21 00 11 00 00 90 11 00  device_store     0, i32, x, r0, u6_u7, r1.discard, lsl 2, 0, wait 3, 1, 1
 258: 0E 00 00 00                                stop             
