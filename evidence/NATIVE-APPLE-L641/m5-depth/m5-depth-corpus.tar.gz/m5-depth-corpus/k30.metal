#include <metal_stdlib>
using namespace metal;
kernel void k(volatile device const int *w [[buffer(0)]], volatile device const int *x [[buffer(1)]], device int *out [[buffer(2)]], uint gid [[thread_position_in_grid]]) {
uint base = gid * 30;
int s = 0;
s += w[base + 0] * x[0];
s += w[base + 1] * x[1];
s += w[base + 2] * x[2];
s += w[base + 3] * x[3];
s += w[base + 4] * x[4];
s += w[base + 5] * x[5];
s += w[base + 6] * x[6];
s += w[base + 7] * x[7];
s += w[base + 8] * x[8];
s += w[base + 9] * x[9];
s += w[base + 10] * x[10];
s += w[base + 11] * x[11];
s += w[base + 12] * x[12];
s += w[base + 13] * x[13];
s += w[base + 14] * x[14];
s += w[base + 15] * x[15];
s += w[base + 16] * x[16];
s += w[base + 17] * x[17];
s += w[base + 18] * x[18];
s += w[base + 19] * x[19];
s += w[base + 20] * x[20];
s += w[base + 21] * x[21];
s += w[base + 22] * x[22];
s += w[base + 23] * x[23];
s += w[base + 24] * x[24];
s += w[base + 25] * x[25];
s += w[base + 26] * x[26];
s += w[base + 27] * x[27];
s += w[base + 28] * x[28];
s += w[base + 29] * x[29];
out[gid] = s;
}
