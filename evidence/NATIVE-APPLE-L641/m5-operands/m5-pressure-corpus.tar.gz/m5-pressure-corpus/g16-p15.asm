   0: 0E 00 00 00                                stop             
