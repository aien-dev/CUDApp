#include <metal_stdlib>
using namespace metal;
kernel void k(volatile device const uint *a [[buffer(0)]], volatile device const uint *b [[buffer(1)]], volatile device const uint *c [[buffer(2)]], device uint *out [[buffer(3)]], uint3 pos [[thread_position_in_grid]]) {
uint gid=pos.x;
uint va=a[gid]; uint vb=b[gid]; uint vc=c[gid];
uint v0=a[gid+1];
uint v1=a[gid+2];
uint v2=a[gid+3];
uint v3=a[gid+4];
uint v4=a[gid+5];
uint v5=a[gid+6];
uint v6=a[gid+7];
uint v7=a[gid+8];
uint v8=a[gid+9];
uint v9=a[gid+10];
uint v10=a[gid+11];
uint v11=a[gid+12];
out[gid] = va * vb + vc;
out[gid+1] = va; out[gid+2] = vb; out[gid+3] = vc;
out[gid+4] = v0;
out[gid+5] = v1;
out[gid+6] = v2;
out[gid+7] = v3;
out[gid+8] = v4;
out[gid+9] = v5;
out[gid+10] = v6;
out[gid+11] = v7;
out[gid+12] = v8;
out[gid+13] = v9;
out[gid+14] = v10;
out[gid+15] = v11;
}
