   0: 9C A0 10 06                                get_sr           0, r9, sr32 (thread_position_in_grid.x)
   4: 67 10 54 0C 00 09 20 00 51 01 00 40 46 00  device_load      5, i32, x, r6, u0_u1, r9, lsl 2, 0, wait 0, 1, 1, 0
  12: 9F 01 54 0E 02 02 48 88 11 04              iadd             r7, 1, r9
  1c: 67 00 54 08 01 09 20 00 51 01 00 40 46 00  device_load      5, i32, x, r4, u2_u3, r9, lsl 2, 0, 1, 1, 0
  2a: 67 00 54 04 02 09 20 00 51 01 00 40 46 00  device_load      5, i32, x, r2, u4_u5, r9, lsl 2, 0, 1, 1, 0
  38: 67 00 44 00 00 07 20 00 11 00 00 40 46 00  device_load      0, i32, x, r0, u0_u1, r7, lsl 2, 0, 1, 0, 0
  46: 9F 00 56 10 02 10 30 20 D0 21 2A 00        imadd            r8, r4, r6, r2, wait 5
  52: 9F 01 54 0A 02 04 48 8C 11 04              iadd             r5, 2, r9.cache
  5c: 9F 01 54 06 02 06 48 8C 11 04              iadd             r3, 3, r9.cache
  66: 9F 01 54 02 02 08 48 88 11 04              iadd             r1, 4, r9
  70: E7 00 54 10 03 09 21 00 11 00 00 90 11 00  device_store     0, i32, x, r8, u6_u7, r9.discard, lsl 2, 0, 1, 1
  7e: E7 00 54 0C 03 07 21 00 11 00 00 90 11 00  device_store     0, i32, x, r6, u6_u7, r7.discard, lsl 2, 0, 1, 1
  8c: E7 00 54 08 03 05 21 00 11 00 00 90 11 00  device_store     0, i32, x, r4, u6_u7, r5.discard, lsl 2, 0, 1, 1
  9a: E7 00 54 04 03 03 21 00 11 00 00 90 11 00  device_store     0, i32, x, r2, u6_u7, r3.discard, lsl 2, 0, 1, 1
  a8: E7 10 54 00 03 01 21 00 11 00 00 90 11 00  device_store     0, i32, x, r0, u6_u7, r1.discard, lsl 2, 0, wait 0, 1, 1
  b6: 0E 00 00 00                                stop             
