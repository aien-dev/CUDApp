#include <metal_stdlib>
using namespace metal;
kernel void k(volatile device const uint *a [[buffer(0)]], volatile device const uint *b [[buffer(1)]], volatile device const uint *c [[buffer(2)]], device uint *out [[buffer(3)]], uint gid [[thread_position_in_grid]]) {
uint j=b[gid];
uint addr=j+5;
uint v=a[addr];
out[gid]=v; out[gid+1]=addr; out[gid+2]=j;
}
