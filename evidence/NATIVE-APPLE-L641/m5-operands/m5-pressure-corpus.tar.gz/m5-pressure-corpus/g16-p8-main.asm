   0: 1C A0 10 06                                get_sr           0, r1, sr32 (thread_position_in_grid.x)
   4: 67 10 54 28 00 01 20 00 51 01 00 40 46 00  device_load      5, i32, x, r20, u0_u1, r1, lsl 2, 0, wait 0, 1, 1, 0
  12: 67 00 54 24 01 01 20 00 51 01 00 40 46 00  device_load      5, i32, x, r18, u2_u3, r1, lsl 2, 0, 1, 1, 0
  20: 67 00 44 20 02 01 20 00 51 01 00 40 46 00  device_load      5, i32, x, r16, u4_u5, r1, lsl 2, 0, 1, 0, 0
  2e: 9F 01 54 2A 02 02 08 8C 11 04              iadd             r21, 1, r1.cache
  38: 9F 01 54 26 02 04 08 8C 11 04              iadd             r19, 2, r1.cache
  42: 9F 01 54 22 02 06 08 8C 11 04              iadd             r17, 3, r1.cache
  4c: 9F 01 64 1E 02 08 08 8C 11 04              iadd.q2.todo     r15, 4, r1.cache
  56: 9F 01 54 1A 02 0A 08 8C 11 04              iadd             r13, 5, r1.cache
  60: 9F 01 54 16 02 0C 08 8C 11 04              iadd             r11, 6, r1.cache
  6a: 9F 01 54 12 02 0E 08 8C 11 04              iadd             r9, 7, r1.cache
  74: 9F 01 54 0E 02 10 08 88 11 04              iadd             r7, 8, r1
  7e: 67 00 54 1C 00 15 20 00 11 00 00 40 46 00  device_load      0, i32, x, r14, u0_u1, r21, lsl 2, 0, 1, 1, 0
  8c: 67 00 54 18 00 13 20 00 51 00 00 40 46 00  device_load      1, i32, x, r12, u0_u1, r19, lsl 2, 0, 1, 1, 0
  9a: 67 00 54 14 00 11 20 00 91 00 00 40 46 00  device_load      2, i32, x, r10, u0_u1, r17, lsl 2, 0, 1, 1, 0
  a8: 67 00 54 10 00 0F 20 00 91 00 00 40 46 00  device_load      2, i32, x, r8, u0_u1, r15, lsl 2, 0, 1, 1, 0
  b6: 67 00 54 0C 00 0D 20 00 91 00 00 40 46 00  device_load      2, i32, x, r6, u0_u1, r13, lsl 2, 0, 1, 1, 0
  c4: 67 00 54 08 00 0B 20 00 11 01 00 40 46 00  device_load      4, i32, x, r4, u0_u1, r11, lsl 2, 0, 1, 1, 0
  d2: 67 00 54 04 00 09 20 00 11 01 00 40 46 00  device_load      4, i32, x, r2, u0_u1, r9, lsl 2, 0, 1, 1, 0
  e0: 67 00 44 00 00 07 20 00 D1 00 00 40 46 00  device_load      3, i32, x, r0, u0_u1, r7, lsl 2, 0, 1, 0, 0
  ee: 9F 00 56 06 02 48 A0 00 D1 21 2A 00        imadd            r3, r18, r20, r16, wait 5
  fa: E7 00 54 06 03 01 20 00 51 00 00 90 11 00  device_store     1, i32, x, r3, u6_u7, r1, lsl 2, 0, 1, 1
 108: 9F 01 54 0A 02 12 08 8C 11 04              iadd             r5, 9, r1.cache
 112: 9F 01 54 06 02 14 08 8C 11 04              iadd             r3, 10, r1.cache
 11c: 9F 01 54 02 02 16 08 88 15 04              iadd             r1, 11, r1.discard
 126: E7 00 54 28 03 15 21 00 51 00 00 90 11 00  device_store     1, i32, x, r20, u6_u7, r21.discard, lsl 2, 0, 1, 1
 134: E7 00 54 24 03 13 21 00 11 00 00 90 11 00  device_store     0, i32, x, r18, u6_u7, r19.discard, lsl 2, 0, 1, 1
 142: E7 00 54 20 03 11 21 00 11 00 00 90 11 00  device_store     0, i32, x, r16, u6_u7, r17.discard, lsl 2, 0, 1, 1
 150: E7 10 54 1C 03 0F 21 00 11 00 00 90 11 00  device_store     0, i32, x, r14, u6_u7, r15.discard, lsl 2, 0, wait 0, 1, 1
 15e: E7 20 54 18 03 0D 21 00 11 00 00 90 11 00  device_store     0, i32, x, r12, u6_u7, r13.discard, lsl 2, 0, wait 1, 1, 1
 16c: E7 40 54 14 03 0B 21 00 11 00 00 90 11 00  device_store     0, i32, x, r10, u6_u7, r11.discard, lsl 2, 0, wait 2, 1, 1
 17a: E7 00 54 10 03 09 21 00 11 00 00 90 11 00  device_store     0, i32, x, r8, u6_u7, r9.discard, lsl 2, 0, 1, 1
 188: E7 00 54 0C 03 07 21 00 11 00 00 90 11 00  device_store     0, i32, x, r6, u6_u7, r7.discard, lsl 2, 0, 1, 1
 196: E7 00 55 08 03 05 21 00 11 00 00 90 11 00  device_store     0, i32, x, r4, u6_u7, r5.discard, lsl 2, 0, wait 4, 1, 1
 1a4: E7 00 54 04 03 03 21 00 11 00 00 90 11 00  device_store     0, i32, x, r2, u6_u7, r3.discard, lsl 2, 0, 1, 1
 1b2: E7 80 54 00 03 01 21 00 11 00 00 90 11 00  device_store     0, i32, x, r0, u6_u7, r1.discard, lsl 2, 0, wait 3, 1, 1
 1c0: 0E 00 00 00                                stop             
