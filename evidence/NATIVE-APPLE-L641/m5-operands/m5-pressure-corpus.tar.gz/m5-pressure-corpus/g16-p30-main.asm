   0: 1C A0 10 06                                get_sr           0, r1, sr32 (thread_position_in_grid.x)
   4: 9F 11 54 7E 02 02 08 8C 11 04              iadd             r63, 1, r1.cache, wait 0
   e: 9F 01 54 7A 02 04 08 8C 11 04              iadd             r61, 2, r1.cache
  18: 9F 01 54 76 02 06 08 8C 11 04              iadd             r59, 3, r1.cache
  22: 9F 01 64 72 02 08 08 8C 11 04              iadd.q2.todo     r57, 4, r1.cache
  2c: 9F 01 54 6E 02 0A 08 8C 11 04              iadd             r55, 5, r1.cache
  36: 9F 01 54 6A 02 0C 08 8C 11 04              iadd             r53, 6, r1.cache
  40: 9F 01 54 66 02 0E 08 8C 11 04              iadd             r51, 7, r1.cache
  4a: 9F 01 54 62 02 10 08 88 11 04              iadd             r49, 8, r1
  54: 67 00 54 7C 00 01 20 00 11 00 00 40 46 00  device_load      0, i32, x, r62, u0_u1, r1, lsl 2, 0, 1, 1, 0
  62: 67 00 54 78 01 01 20 00 11 00 00 40 46 00  device_load      0, i32, x, r60, u2_u3, r1, lsl 2, 0, 1, 1, 0
  70: 67 00 54 74 02 01 20 00 11 00 00 40 46 00  device_load      0, i32, x, r58, u4_u5, r1, lsl 2, 0, 1, 1, 0
  7e: 67 00 54 70 00 3F 20 00 51 00 00 40 46 00  device_load      1, i32, x, r56, u0_u1, r63, lsl 2, 0, 1, 1, 0
  8c: 67 00 54 6C 00 3D 20 00 51 00 00 40 46 00  device_load      1, i32, x, r54, u0_u1, r61, lsl 2, 0, 1, 1, 0
  9a: 67 00 54 68 00 3B 20 00 51 00 00 40 46 00  device_load      1, i32, x, r52, u0_u1, r59, lsl 2, 0, 1, 1, 0
  a8: 67 00 54 64 00 39 20 00 51 00 00 40 46 00  device_load      1, i32, x, r50, u0_u1, r57, lsl 2, 0, 1, 1, 0
  b6: 67 00 54 60 00 37 20 00 51 00 00 40 46 00  device_load      1, i32, x, r48, u0_u1, r55, lsl 2, 0, 1, 1, 0
  c4: 67 00 54 5C 00 35 20 00 51 00 00 40 46 00  device_load      1, i32, x, r46, u0_u1, r53, lsl 2, 0, 1, 1, 0
  d2: 67 00 54 58 00 33 20 00 51 00 00 40 46 00  device_load      1, i32, x, r44, u0_u1, r51, lsl 2, 0, 1, 1, 0
  e0: 67 00 44 54 00 31 20 00 51 00 00 40 46 00  device_load      1, i32, x, r42, u0_u1, r49, lsl 2, 0, 1, 0, 0
  ee: 9F 01 54 5E 02 12 08 8C 11 04              iadd             r47, 9, r1.cache
  f8: 9F 01 54 5A 02 14 08 8C 11 04              iadd             r45, 10, r1.cache
 102: 9F 01 54 56 02 16 08 8C 11 04              iadd             r43, 11, r1.cache
 10c: 9F 01 54 52 02 18 08 8C 11 04              iadd             r41, 12, r1.cache
 116: 9F 01 54 4E 02 1A 08 8C 11 04              iadd             r39, 13, r1.cache
 120: 9F 01 54 4A 02 1C 08 8C 11 04              iadd             r37, 14, r1.cache
 12a: 9F 01 64 46 02 1E 08 8C 11 04              iadd.q2.todo     r35, 15, r1.cache
 134: 9F 01 54 42 02 20 08 8C 11 04              iadd             r33, 16, r1.cache
 13e: 9F 01 54 3E 02 22 08 8C 11 04              iadd             r31, 17, r1.cache
 148: 9F 01 54 3A 02 24 08 8C 11 04              iadd             r29, 18, r1.cache
 152: 9F 01 54 36 02 26 08 8C 11 04              iadd             r27, 19, r1.cache
 15c: 67 00 54 50 00 2F 20 00 51 00 00 40 46 00  device_load      1, i32, x, r40, u0_u1, r47, lsl 2, 0, 1, 1, 0
 16a: 67 00 54 4C 00 2D 20 00 51 00 00 40 46 00  device_load      1, i32, x, r38, u0_u1, r45, lsl 2, 0, 1, 1, 0
 178: 67 00 54 48 00 2B 20 00 51 00 00 40 46 00  device_load      1, i32, x, r36, u0_u1, r43, lsl 2, 0, 1, 1, 0
 186: 67 00 54 44 00 29 20 00 51 00 00 40 46 00  device_load      1, i32, x, r34, u0_u1, r41, lsl 2, 0, 1, 1, 0
 194: 67 00 54 40 00 27 20 00 91 00 00 40 46 00  device_load      2, i32, x, r32, u0_u1, r39, lsl 2, 0, 1, 1, 0
 1a2: 67 00 54 3C 00 25 20 00 91 00 00 40 46 00  device_load      2, i32, x, r30, u0_u1, r37, lsl 2, 0, 1, 1, 0
 1b0: 67 00 54 38 00 23 20 00 91 00 00 40 46 00  device_load      2, i32, x, r28, u0_u1, r35, lsl 2, 0, 1, 1, 0
 1be: 67 00 54 34 00 21 20 00 91 00 00 40 46 00  device_load      2, i32, x, r26, u0_u1, r33, lsl 2, 0, 1, 1, 0
 1cc: 67 00 54 30 00 1F 20 00 91 00 00 40 46 00  device_load      2, i32, x, r24, u0_u1, r31, lsl 2, 0, 1, 1, 0
 1da: 67 00 54 2C 00 1D 20 00 91 00 00 40 46 00  device_load      2, i32, x, r22, u0_u1, r29, lsl 2, 0, 1, 1, 0
 1e8: 67 00 44 06 00 1B 20 00 91 00 00 40 46 00  device_load      2, i32, x, r3, u0_u1, r27, lsl 2, 0, 1, 0, 0
 1f6: 9F 01 54 32 02 28 08 8C 11 04              iadd             r25, 20, r1.cache
 200: 9F 01 54 2E 02 2A 08 8C 11 04              iadd             r23, 21, r1.cache
 20a: 9F 01 54 0A 02 2C 08 8C 11 04              iadd             r5, 22, r1.cache
 214: 9F 01 54 2A 02 2E 08 8C 11 04              iadd             r21, 23, r1.cache
 21e: 9F 01 54 26 02 30 08 8C 11 04              iadd             r19, 24, r1.cache
 228: 9F 01 54 22 02 32 08 8C 11 04              iadd             r17, 25, r1.cache
 232: 9F 01 64 1E 02 34 08 8C 11 04              iadd.q2.todo     r15, 26, r1.cache
 23c: 9F 01 54 1A 02 36 08 8C 11 04              iadd             r13, 27, r1.cache
 246: 9F 01 54 16 02 38 08 8C 11 04              iadd             r11, 28, r1.cache
 250: 9F 01 54 12 02 3A 08 8C 11 04              iadd             r9, 29, r1.cache
 25a: 9F 01 54 0E 02 3C 08 88 11 04              iadd             r7, 30, r1
 264: 67 00 54 28 00 19 20 00 11 01 00 40 46 00  device_load      4, i32, x, r20, u0_u1, r25, lsl 2, 0, 1, 1, 0
 272: 67 00 54 24 00 17 20 00 11 01 00 40 46 00  device_load      4, i32, x, r18, u0_u1, r23, lsl 2, 0, 1, 1, 0
 280: 67 00 54 20 00 05 20 00 11 01 00 40 46 00  device_load      4, i32, x, r16, u0_u1, r5, lsl 2, 0, 1, 1, 0
 28e: 67 00 54 1C 00 15 20 00 11 01 00 40 46 00  device_load      4, i32, x, r14, u0_u1, r21, lsl 2, 0, 1, 1, 0
 29c: 67 00 54 18 00 13 20 00 11 01 00 40 46 00  device_load      4, i32, x, r12, u0_u1, r19, lsl 2, 0, 1, 1, 0
 2aa: 67 00 54 14 00 11 20 00 11 01 00 40 46 00  device_load      4, i32, x, r10, u0_u1, r17, lsl 2, 0, 1, 1, 0
 2b8: 67 00 54 10 00 0F 20 00 D1 00 00 40 46 00  device_load      3, i32, x, r8, u0_u1, r15, lsl 2, 0, 1, 1, 0
 2c6: 67 00 54 0C 00 0D 20 00 D1 00 00 40 46 00  device_load      3, i32, x, r6, u0_u1, r13, lsl 2, 0, 1, 1, 0
 2d4: 67 00 54 08 00 0B 20 00 D1 00 00 40 46 00  device_load      3, i32, x, r4, u0_u1, r11, lsl 2, 0, 1, 1, 0
 2e2: 67 00 54 04 00 09 20 00 D1 00 00 40 46 00  device_load      3, i32, x, r2, u0_u1, r9, lsl 2, 0, 1, 1, 0
 2f0: 67 00 44 00 00 07 20 00 51 01 00 40 46 00  device_load      5, i32, x, r0, u0_u1, r7, lsl 2, 0, 1, 0, 0
 2fe: 9F 10 54 80 02 F0 F0 A1 D3 21 2A 00        imadd            r64, r60, r62, r58, wait 0
 30a: E7 00 54 80 03 01 20 00 51 00 00 90 11 00  device_store     1, i32, x, r64, u6_u7, r1, lsl 2, 0, 1, 1
 318: E7 00 54 7C 03 3F 21 00 51 00 00 90 11 00  device_store     1, i32, x, r62, u6_u7, r63.discard, lsl 2, 0, 1, 1
 326: E7 00 54 78 03 3D 21 00 51 00 00 90 11 00  device_store     1, i32, x, r60, u6_u7, r61.discard, lsl 2, 0, 1, 1
 334: E7 00 54 74 03 3B 21 00 51 00 00 90 11 00  device_store     1, i32, x, r58, u6_u7, r59.discard, lsl 2, 0, 1, 1
 342: E7 20 54 70 03 39 21 00 51 00 00 90 11 00  device_store     1, i32, x, r56, u6_u7, r57.discard, lsl 2, 0, wait 1, 1, 1
 350: E7 00 54 6C 03 37 21 00 51 00 00 90 11 00  device_store     1, i32, x, r54, u6_u7, r55.discard, lsl 2, 0, 1, 1
 35e: E7 00 54 68 03 35 21 00 51 00 00 90 11 00  device_store     1, i32, x, r52, u6_u7, r53.discard, lsl 2, 0, 1, 1
 36c: E7 00 54 64 03 33 21 00 51 00 00 90 11 00  device_store     1, i32, x, r50, u6_u7, r51.discard, lsl 2, 0, 1, 1
 37a: E7 00 54 60 03 31 21 00 51 00 00 90 11 00  device_store     1, i32, x, r48, u6_u7, r49.discard, lsl 2, 0, 1, 1
 388: E7 00 54 5C 03 2F 21 00 51 00 00 90 11 00  device_store     1, i32, x, r46, u6_u7, r47.discard, lsl 2, 0, 1, 1
 396: E7 00 54 58 03 2D 21 00 51 00 00 90 11 00  device_store     1, i32, x, r44, u6_u7, r45.discard, lsl 2, 0, 1, 1
 3a4: E7 00 54 54 03 2B 21 00 51 00 00 90 11 00  device_store     1, i32, x, r42, u6_u7, r43.discard, lsl 2, 0, 1, 1
 3b2: E7 00 54 50 03 29 21 00 51 00 00 90 11 00  device_store     1, i32, x, r40, u6_u7, r41.discard, lsl 2, 0, 1, 1
 3c0: E7 00 54 4C 03 27 21 00 51 00 00 90 11 00  device_store     1, i32, x, r38, u6_u7, r39.discard, lsl 2, 0, 1, 1
 3ce: E7 00 54 48 03 25 21 00 51 00 00 90 11 00  device_store     1, i32, x, r36, u6_u7, r37.discard, lsl 2, 0, 1, 1
 3dc: E7 00 54 44 03 23 21 00 51 00 00 90 11 00  device_store     1, i32, x, r34, u6_u7, r35.discard, lsl 2, 0, 1, 1
 3ea: E7 40 54 40 03 21 21 00 51 00 00 90 11 00  device_store     1, i32, x, r32, u6_u7, r33.discard, lsl 2, 0, wait 2, 1, 1
 3f8: E7 00 54 3C 03 1F 21 00 51 00 00 90 11 00  device_store     1, i32, x, r30, u6_u7, r31.discard, lsl 2, 0, 1, 1
 406: E7 00 54 38 03 1D 21 00 51 00 00 90 11 00  device_store     1, i32, x, r28, u6_u7, r29.discard, lsl 2, 0, 1, 1
 414: E7 00 54 34 03 1B 21 00 51 00 00 90 11 00  device_store     1, i32, x, r26, u6_u7, r27.discard, lsl 2, 0, 1, 1
 422: E7 00 54 30 03 19 21 00 51 00 00 90 11 00  device_store     1, i32, x, r24, u6_u7, r25.discard, lsl 2, 0, 1, 1
 430: E7 00 54 2C 03 17 21 00 51 00 00 90 11 00  device_store     1, i32, x, r22, u6_u7, r23.discard, lsl 2, 0, 1, 1
 43e: E7 00 54 06 03 05 21 00 51 00 00 90 11 00  device_store     1, i32, x, r3, u6_u7, r5.discard, lsl 2, 0, 1, 1
 44c: 9F 01 54 0A 02 3E 08 8C 11 04              iadd             r5, 31, r1.cache
 456: 9F 01 54 06 02 40 08 8C 11 04              iadd             r3, 32, r1.cache
 460: 9F 01 54 02 02 42 08 88 15 04              iadd             r1, 33, r1.discard
 46a: E7 00 55 28 03 15 21 00 51 00 00 90 11 00  device_store     1, i32, x, r20, u6_u7, r21.discard, lsl 2, 0, wait 4, 1, 1
 478: E7 00 54 24 03 13 21 00 11 00 00 90 11 00  device_store     0, i32, x, r18, u6_u7, r19.discard, lsl 2, 0, 1, 1
 486: E7 00 54 20 03 11 21 00 11 00 00 90 11 00  device_store     0, i32, x, r16, u6_u7, r17.discard, lsl 2, 0, 1, 1
 494: E7 00 54 1C 03 0F 21 00 11 00 00 90 11 00  device_store     0, i32, x, r14, u6_u7, r15.discard, lsl 2, 0, 1, 1
 4a2: E7 00 54 18 03 0D 21 00 11 00 00 90 11 00  device_store     0, i32, x, r12, u6_u7, r13.discard, lsl 2, 0, 1, 1
 4b0: E7 00 54 14 03 0B 21 00 11 00 00 90 11 00  device_store     0, i32, x, r10, u6_u7, r11.discard, lsl 2, 0, 1, 1
 4be: E7 80 54 10 03 09 21 00 11 00 00 90 11 00  device_store     0, i32, x, r8, u6_u7, r9.discard, lsl 2, 0, wait 3, 1, 1
 4cc: E7 00 54 0C 03 07 21 00 11 00 00 90 11 00  device_store     0, i32, x, r6, u6_u7, r7.discard, lsl 2, 0, 1, 1
 4da: E7 00 54 08 03 05 21 00 11 00 00 90 11 00  device_store     0, i32, x, r4, u6_u7, r5.discard, lsl 2, 0, 1, 1
 4e8: E7 00 54 04 03 03 21 00 11 00 00 90 11 00  device_store     0, i32, x, r2, u6_u7, r3.discard, lsl 2, 0, 1, 1
 4f6: E7 00 56 00 03 01 21 00 11 00 00 90 11 00  device_store     0, i32, x, r0, u6_u7, r1.discard, lsl 2, 0, wait 5, 1, 1
 504: 0E 00 00 00                                stop             
