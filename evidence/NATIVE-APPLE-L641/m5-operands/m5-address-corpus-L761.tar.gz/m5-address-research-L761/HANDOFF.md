# L761 handoff — G17 address-family discriminator

**Status: complete, compile-only source/corpus evidence; no GPU launch.** Parent owns review and publication. The shared research core stayed frozen at `da94831331abd3c66d05541fc53017ce4ed30371`; L751 was not reopened. No shared interpreter/backend, PR, ledger, model, service, or device state was changed.

## Artifacts

Private Mac namespace: `/Users/drakestapleton/.hermes/cache/scratch/amd-agx-native/lab/m5-address-research-L761/`

- Native Omega producer: `m5-address-input.om`
- Exact source goldens: `test-m5-address-input.om` (selector 0), `test-m5-address-input-{4,8,12,15}.om`
- Refusal gate: `test-m5-address-refusals.om`
- Source hashes: `SOURCE-SHA256SUMS`
- Captures: `corpus/` (16 `.metal`, 16 `.metallib`, 32 `.gpubin`, 32 `.text`, 32 `.macho`, 32 symbol reports, logs, G16 disassemblies, and `SHA256SUMS`)
- Bounded byte/dataflow findings and limits: `EVIDENCE.md`

Spark's only private working directory is `~/handoffs/native-apple-L641/L761-address` (mode 0700). It contains the compiled AArch64 producer and Omega test binaries; those were run on Spark. The executable bytes are Linux AArch64 and are not runnable on the Mac.

## Gates and actual outcomes

- RED: selector-0 exact golden rejected the prior incompatible producer, test status 1 (old MSL was 469 bytes).
- GREEN: exact goldens passed for selectors 0, 4, 8, 12, and 15. This covers all four address expressions and pressure 3.
- Refusals: empty, extra byte, selector 16, and selector 255 each ended with status 65 and empty stdout; native Omega refusal gate passed four cases. A pre-fix extra-byte run incorrectly accepted two bytes and emitted 359 bytes; it is retained as a failed attempt, then corrected by reading/checking EOF and rerun green.
- Apple Metal source frontend compiled 16/16 cases; `air-tt` compiled 32/32 G16/G17 cases; all extracted `.text`/`.macho` artifacts are nonempty.
- Every one of 32 symbol outputs contains exact `_agc.main` at `0x40`; the separate `_agc.main.constant_program` at `0` was not counted as main.
- All 16 G16 bodies decoded after skipping the true symbol prefix, with no decoder warnings. G16 results are not a G17 decoder.
- `corpus/SHA256SUMS` has 273 entries and `shasum -c` passed. Capture membership was compared to all 16 final MSL sources.

Exact compile recipe and the evidence table, including the candidate G17 byte spans and caveats, are in `EVIDENCE.md`. Tool fingerprints and all source/output hashes are recorded there and in the manifests.

## Findings / boundaries

Same-pressure G17 captures change the address-side bytes: selector 0 (`addr=gid`) vs 8 (`addr=j`) changes the candidate load `+5` byte at `.text` offset `0x55` from `00` to `20`, while the load-like byte `+1` remains `02`; the preceding address span and register assignment also change. Constant `+5` variants add 12 bytes at pressure 0, but the p3 `gid+5` case has the same total length as `gid` p3, so this is not a one-byte-minimal-pair result. Retained-register pressure changes instruction order/register bytes. The capture suggests a discriminating index-register candidate but does not prove G17 field semantics or physical register identity. `EVIDENCE.md` explicitly records that this source materializes `addr` and therefore is not the reference's literal direct `a[gid]` control.

The source is intentionally unsafe to execute: `j` can yield an out-of-bounds `a` address and per-lane stores overlap. No kernel was launched. Remaining: independent G17 decoding/field verification, physical/dependency/cache semantics, and parent review/publication.

## Pins / hashes

- Seed `omc`: `191b776ef98821597c3e30655da6d680a9b66edbc9ceaca3c39c61ea6df098e9`
- Final producer `.om`: `7bd3f1e231041294eae69e661214f516bc5144e81081b12e97cb6c36af3523ce`
- Final generator ELF (`address-generator-r2`): `aa11b80ce31e02b96c5b17ca8a43681c01c5c2aac9532d9e46ffc386ca6fa42c`
- Capture manifest: `corpus/SHA256SUMS` SHA256 `90b263e2c94f375f614ab4f7136cdfe3587a511d893e0d8601735941b75274c1`
- External reference: upstream `ADevWithAnIdea/agx-re` pin `c677ff970ca9d5ab98770100e790f8a62c60a2a0`; cited EXP-M5-11 patch SHA256 `e3ee2a8d2d26584fa200f2fe7bd8d1d62fa07b5716270d6b13877d76cdab13d9`. It remains attributed third-party evidence, not this experiment's hardware result.

No shared work was pushed or published; parent verification remains outstanding.
